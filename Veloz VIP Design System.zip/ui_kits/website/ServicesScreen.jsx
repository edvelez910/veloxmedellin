const {Hero,Pill,Button,SectionHeading,Eyebrow,FeatureCard,CtaCard,Icon,SpecChip,LocationPill,StepCard}=window.VelozVIPDesignSystem_b0ea98;
const D=window.VELOX_DATA;
const svcWrap={maxWidth:'var(--maxw)',margin:'0 auto',padding:'0 var(--gutter)'};

function ServicesScreen({onNavigate}){
  const [open,setOpen]=React.useState('transfer');
  const active=D.services.find(s=>s.id===open)||D.services[0];
  return (
    <div>
      <Hero minHeight="62vh" image="https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?auto=format&fit=crop&w=2000&q=80" megaWord="SERVICIOS"
        title="Portafolio de soluciones"
        subtitle="Cuatro formas de movernos contigo: transfers, movilidad por bloques, eventos y experiencias."
        badges={<><Pill tone="glass" iconName="map-pin">Medellín y alrededores</Pill><Pill tone="glass" iconName="clock">Disponibilidad por horas o días</Pill></>}/>

      <section style={{padding:'90px 0 40px'}}>
        <div style={svcWrap}>
          <SectionHeading eyebrow="Elige tu servicio" title="Cada trayecto tiene una logística distinta" style={{marginBottom:44}}/>
          <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:14,marginBottom:34}}>
            {D.services.map(s=>{
              const on=s.id===open;
              return <button key={s.id} onClick={()=>setOpen(s.id)} style={{textAlign:'left',cursor:'pointer',background:on?'var(--surface-inverse)':'var(--surface-card)',color:on?'var(--text-on-dark)':'var(--text-body)',
                border:'1px solid '+(on?'var(--border-gold)':'var(--border-hairline)'),borderRadius:'var(--r-xl)',padding:'20px 20px 22px',transition:'background var(--dur-fast),border-color var(--dur-fast)'}}>
                <span style={{display:'grid',placeItems:'center',width:44,height:44,borderRadius:'var(--r-sm)',border:'1px solid '+(on?'var(--border-gold)':'var(--border-hairline)'),color:on?'var(--text-accent-on-dark)':'var(--text-accent)',marginBottom:16}}><Icon name={s.iconName} size={22}/></span>
                <span style={{display:'block',fontFamily:'var(--font-display)',fontSize:18,fontWeight:700,marginBottom:6}}>{s.name}</span>
                <span style={{display:'block',fontFamily:'var(--font-caps)',fontSize:11,letterSpacing:'var(--ls-caps-sm)',textTransform:'uppercase',color:on?'var(--text-on-dark-faint)':'var(--text-faint)'}}>{s.meta}</span>
              </button>;
            })}
          </div>
          <div style={{display:'grid',gridTemplateColumns:'1.1fr 1fr',gap:40,alignItems:'stretch',background:'var(--surface-card)',border:'1px solid var(--border-hairline)',borderRadius:'var(--r-3xl)',padding:22}}>
            <div style={{borderRadius:'var(--r-xl)',overflow:'hidden',minHeight:330}}>
              <img src={active.image} alt={active.name} style={{width:'100%',height:'100%',objectFit:'cover'}}/>
            </div>
            <div style={{padding:'18px 18px 18px 0',display:'flex',flexDirection:'column'}}>
              <Eyebrow tone="gold">{active.meta}</Eyebrow>
              <h3 style={{margin:'14px 0 16px',fontFamily:'var(--font-display)',fontSize:'var(--fs-display-3)',fontWeight:700,letterSpacing:'var(--ls-tight)',color:'var(--text-strong)'}}>{active.name}</h3>
              <p style={{margin:'0 0 24px',color:'var(--text-muted)',fontSize:'var(--fs-body-lg)',lineHeight:'var(--lh-relaxed)'}}>{active.copy}</p>
              <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:'auto'}}>
                <SpecChip iconName="shield-check">Conductor verificado</SpecChip>
                <SpecChip iconName="radar">Seguimiento en vivo</SpecChip>
                <SpecChip iconName="receipt">Tarifa cerrada</SpecChip>
              </div>
              <div style={{display:'flex',gap:12,marginTop:26,flexWrap:'wrap'}}>
                <Button variant="gold" arrow onClick={()=>onNavigate('reserva')}>Reservar este servicio</Button>
                <Button variant="light" onClick={()=>onNavigate('flota')}>Ver vehículos</Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section style={{padding:'50px 0 90px'}}>
        <div style={svcWrap}>
          <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:'var(--gap-bento)',marginBottom:'var(--gap-bento)'}}>
            <FeatureCard image="https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&w=900&q=80" iconName="plane-landing" title="Recepción en aeropuerto">Marcador personalizado, bienvenida cálida y ayuda con el equipaje hasta el vehículo.</FeatureCard>
            <FeatureCard image="https://images.unsplash.com/photo-1519671482749-fd09be7ccebf?auto=format&fit=crop&w=900&q=80" iconName="party-popper" title="Eventos y ocasiones">Bodas, conciertos y fiestas privadas con retorno seguro garantizado.</FeatureCard>
            <FeatureCard image="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=900&q=80" iconName="utensils" title="Reservas y alianzas">Mesas en los mejores restaurantes y tours privados con agencias aliadas.</FeatureCard>
          </div>
          <div style={{marginBottom:40}}>
            <div style={{fontSize:'var(--fs-body-sm)',color:'var(--text-muted)',fontWeight:600,marginBottom:16}}>Cobertura habitual</div>
            <div style={{display:'flex',flexWrap:'wrap',gap:12}}>{D.destinations.map(d=><LocationPill key={d.name} name={d.name} image={d.image}/>)}</div>
          </div>
          <CtaCard tone="dark" iconName="message-circle" title="Escríbenos con tu itinerario y te respondemos en minutos." action={<Button variant="gold" arrow onClick={()=>onNavigate('reserva')}>Hablar con Velox</Button>}/>
        </div>
      </section>
    </div>
  );
}
Object.assign(window,{ServicesScreen});
