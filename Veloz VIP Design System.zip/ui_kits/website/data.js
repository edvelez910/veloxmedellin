// Content used across the Velox VIP website kit. Copy tone: Spanish (Colombia), usted implícito → "tú" cercano.
window.VELOX_DATA = {
  nav:[{id:'home',label:'Inicio'},{id:'servicios',label:'Servicios'},{id:'flota',label:'Flota'},{id:'reserva',label:'Reservar'}],
  fleet:[
    {id:'sedan',name:'Sedán & Hatchback',category:'Ejecutivo · parejas',image:'https://images.unsplash.com/photo-1553440569-bcc63803a83d?auto=format&fit=crop&w=900&q=80',
     specs:[{iconName:'users',label:'1–3 pasajeros'},{iconName:'briefcase',label:'2 maletas'},{iconName:'snowflake',label:'A/C'}],
     price:'Desde COP 90.000',unit:'/ trayecto',footnote:'Cómodo, ágil y de alta calidad a un precio accesible.'},
    {id:'suv',name:'SUV & Camionetas',category:'Familias · corporativo',image:'https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&w=900&q=80',
     specs:[{iconName:'users',label:'4–6 pasajeros'},{iconName:'briefcase',label:'4 maletas'},{iconName:'shield-check',label:'Conductor verificado'}],
     price:'Desde COP 150.000',unit:'/ trayecto',footnote:'Espacio superior, máximo confort y elegancia.'},
    {id:'van',name:'Vans & Gran capacidad',category:'Grupos · delegaciones',image:'https://images.unsplash.com/photo-1464219789935-c2d9d9aba644?auto=format&fit=crop&w=900&q=80',
     specs:[{iconName:'users',label:'7–15 pasajeros'},{iconName:'briefcase',label:'Equipaje amplio'},{iconName:'route',label:'Itinerario completo'}],
     price:'Desde COP 320.000',unit:'/ trayecto',footnote:'Logística perfecta para eventos y traslados de grupo.'},
    {id:'bloques',name:'Bloques por horas',category:'City concierge',image:'https://images.unsplash.com/photo-1494905998402-395d579af36f?auto=format&fit=crop&w=900&q=80',
     specs:[{iconName:'clock',label:'Mínimo 4 horas'},{iconName:'map-pin',label:'Medellín y área'},{iconName:'user-check',label:'Conductor a disposición'}],
     price:'Desde COP 65.000',unit:'/ hora',footnote:'Reuniones, compras, turismo local o noche.'}
  ],
  services:[
    {id:'transfer',name:'Transfers aeropuerto',meta:'JMC · EOH',iconName:'plane-landing',
     copy:'Monitoreamos la llegada de tu vuelo en tiempo real para estar en la puerta en el momento exacto, sin importar retrasos o adelantos. Marcador personalizado, bienvenida cálida y ayuda completa con el equipaje.',
     image:'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&w=1200&q=80'},
    {id:'concierge',name:'Movilidad por bloques',meta:'Horas o días',iconName:'clock',
     copy:'Conductor privado a disposición para trayectos en la ciudad, reuniones corporativas, salidas de compras o turismo local. Tú defines el itinerario; nosotros la logística.',
     image:'https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?auto=format&fit=crop&w=1200&q=80'},
    {id:'eventos',name:'Eventos & ocasiones',meta:'Retorno garantizado',iconName:'party-popper',
     copy:'Bodas, conciertos, festivales y fiestas privadas con transporte coordinado de principio a fin y retorno seguro garantizado para todos tus invitados.',
     image:'https://images.unsplash.com/photo-1519671482749-fd09be7ccebf?auto=format&fit=crop&w=1200&q=80'},
    {id:'experiencias',name:'Experiencias & alianzas',meta:'Guatapé · Comuna 13',iconName:'utensils',
     copy:'Reservas en los mejores restaurantes de la ciudad y tours privados por Guatapé, Comuna 13, Eje Cafetero y rutas gastronómicas, con agencias aliadas.',
     image:'https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=1200&q=80'}
  ],
  destinations:[
    {name:'Aeropuerto JMC',image:'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&w=120&q=80'},
    {name:'El Poblado',image:'https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=120&q=80'},
    {name:'Laureles',image:'https://images.unsplash.com/photo-1494522855154-9297ac14b55f?auto=format&fit=crop&w=120&q=80'},
    {name:'Guatapé',image:'https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=120&q=80'},
    {name:'Comuna 13',image:'https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&w=120&q=80'},
    {name:'Eje Cafetero',image:'https://images.unsplash.com/photo-1501594907352-04cda38ebc29?auto=format&fit=crop&w=120&q=80'},
    {name:'Oriente antioqueño',image:'https://images.unsplash.com/photo-1506966953602-c20cc11f75e3?auto=format&fit=crop&w=120&q=80'}
  ],
  strip:['https://images.unsplash.com/photo-1544636331-e26879cd4d9b?auto=format&fit=crop&w=600&q=80','https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=600&q=80','https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=600&q=80','https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=600&q=80','https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=600&q=80'],
  testimonials:[
    {rating:5,quote:'El vuelo llegó dos horas tarde y el conductor seguía ahí, con el marcador en la mano. Cero estrés.',name:'Laura Restrepo',role:'Viaje corporativo',photo:'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80'},
    {rating:5,quote:'Coordinaron la boda completa: llegada de invitados, fotos en Guatapé y retorno de madrugada.',name:'Andrés &amp; Sofía',role:'Boda en el Oriente',photo:'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=400&q=80'},
    {rating:4.5,quote:'Reservaron mesa, ajustaron el itinerario dos veces y siempre respondieron en minutos.',name:'Michael T.',role:'Turista, 6 días en Medellín',photo:'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80'}
  ],
  faqs:[
    {q:'¿Qué pasa si mi vuelo se retrasa?',a:'Monitoreamos tu vuelo en tiempo real y ajustamos la hora de recogida sin costo adicional. Si se adelanta, también estamos ahí.'},
    {q:'¿Cómo se cotiza el servicio?',a:'Por itinerario. Nos cuentas fechas, número de pasajeros y qué quieres hacer, y armamos una propuesta según tu tipo de grupo y presupuesto.'},
    {q:'¿El conductor habla inglés?',a:'Tenemos conductores bilingües disponibles; indícalo al reservar y lo asignamos según disponibilidad.'},
    {q:'¿Puedo cambiar el itinerario durante el servicio?',a:'Sí. El conductor queda a tu disposición dentro del bloque contratado y coordinamos ajustes por WhatsApp en el momento.'},
    {q:'¿Atienden fuera de Medellín?',a:'Sí: Oriente antioqueño, Guatapé, Eje Cafetero y rutas intermunicipales, con tarifa acordada previamente.'}
  ]
};
