const {Hero,Pill,Button,SectionHeading,Eyebrow,Marquee,FeatureRow,QuoteCard,VehicleCard,CategoryRow,StepCard,FeatureCard,CtaCard,StatBlock,TestimonialCard,LocationPill,FaqItem,ArrowButton,Icon}=window.VelozVIPDesignSystem_b0ea98;
const D=window.VELOX_DATA;

const veloxSec={padding:'110px 0',position:'relative'};
const veloxWrap={maxWidth:'var(--maxw)',margin:'0 auto',padding:'0 var(--gutter)'};

const COLLAGE=[
  {src:'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?auto=format&fit=crop&w=700&q=80',w:300,h:340,top:0,left:'32%',speed:-30},
  {src:'https://images.unsplash.com/photo-1521791136064-7986c2920216?auto=format&fit=crop&w=600&q=80',w:250,h:250,top:70,left:'56%',speed:40},
  {src:'https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=600&q=80',w:240,h:230,top:180,left:'20%',speed:-20},
  {src:'https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=700&q=80',w:280,h:320,top:280,left:'58%',speed:30},
  {src:'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&w=700&q=80',w:280,h:250,top:320,left:'20%',speed:-40},
  {src:'https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&w=600&q=80',w:250,h:270,top:490,left:'36%',speed:25},
  {src:'https://images.unsplash.com/photo-1501594907352-04cda38ebc29?auto=format&fit=crop&w=700&q=80',w:280,h:250,top:530,left:'53%',speed:-25}
];

function CollageSection(){
  const ref=React.useRef(null);
  const [off,setOff]=React.useState(0);
  React.useEffect(()=>{
    let raf=0;
    const onScroll=()=>{
      if(raf)return;
      raf=requestAnimationFrame(()=>{
        raf=0;
        const el=ref.current; if(!el)return;
        const r=el.getBoundingClientRect();
        setOff(((r.top+r.height/2)-window.innerHeight/2)/window.innerHeight);
      });
    };
    onScroll();window.addEventListener('scroll',onScroll);
    return()=>{window.removeEventListener('scroll',onScroll);if(raf)cancelAnimationFrame(raf);};
  },[]);
  return (
    <section ref={ref} style={{padding:'60px 0 120px',overflow:'hidden'}}>
      <div style={{position:'relative',height:820,maxWidth:1080,margin:'0 auto'}}>
        {COLLAGE.map((c,i)=><img key={i} src={c.src} alt="" style={{position:'absolute',width:c.w,height:c.h,top:c.top,left:c.left,objectFit:'cover',borderRadius:'var(--r-md)',boxShadow:'var(--sh-image)',transform:'translateY('+(off*c.speed)+'px)',willChange:'transform'}}/>)}
      </div>
    </section>
  );
}

function HomeScreen({onNavigate}){
  const [faq,setFaq]=React.useState(0);
  const [ti,setTi]=React.useState(0);
  const t=D.testimonials;
  return (
    <div>
      <Hero image="https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=2000&q=80" megaWord="MEDELLÍN"
        title={<>Tu tranquilidad,<br/>nuestra ruta.</>}
        subtitle="Movilidad privada y concierge de experiencias en Medellín. No somos una app de transporte ni una rentadora: somos tu aliado de confianza en la ciudad."
        badges={<><Pill tone="glass" iconName="plane-landing">Seguimiento de vuelo en tiempo real</Pill><Pill tone="glass" iconName="shield-check">Conductores verificados</Pill><Pill tone="glass" dot>Disponibles ahora</Pill></>}
        actions={<><Button variant="gold" arrow onClick={()=>onNavigate('reserva')}>Reservar por WhatsApp</Button><Button variant="ghost" onClick={()=>onNavigate('flota')}>Ver la flota</Button></>}/>

      {/* ---- Quiénes somos ---- */}
      <section style={{...veloxSec,textAlign:'center'}}>
        <div style={veloxWrap}>
          <Pill>Quiénes somos</Pill>
          <p style={{maxWidth:900,margin:'30px auto 46px',fontFamily:'var(--font-display)',fontSize:'var(--fs-lead)',fontWeight:600,lineHeight:1.32,letterSpacing:'var(--ls-tight)',color:'var(--text-strong)'}}>
            Resolvemos toda la logística de transporte e itinerarios para que viajes con absoluta tranquilidad, seguridad y confort — adaptándonos a tus necesidades, tu grupo y tu presupuesto.
          </p>
          <div style={{display:'flex',justifyContent:'center',gap:60,flexWrap:'wrap',marginBottom:70}}>
            <FeatureRow iconName="clock">Puntualidad<br/>impecable</FeatureRow>
            <FeatureRow iconName="shield-check">Seguridad<br/>absoluta</FeatureRow>
            <FeatureRow iconName="radar">Seguimiento<br/>real</FeatureRow>
            <FeatureRow iconName="route">Soluciones<br/>a medida</FeatureRow>
          </div>
        </div>
        <Marquee speed={40} gap={20} style={{margin:'0 0 60px'}}>
          {D.strip.map(s=><img key={s} src={s} alt="" style={{width:300,height:200,objectFit:'cover',borderRadius:'var(--r-lg)',boxShadow:'var(--sh-sm)'}}/>)}
        </Marquee>
        <div style={veloxWrap}>
          <QuoteCard author="Velox VIP Services" role="hospitalidad paisa de alto nivel">“Sofisticado pero cercano: elegantes en la presentación, cálidos en el trato.”</QuoteCard>
        </div>
      </section>

      {/* ---- Servicios: panel partido ---- */}
      <section style={{display:'grid',gridTemplateColumns:'1fr 1fr',minHeight:560}}>
        <div style={{position:'relative',overflow:'hidden'}}>
          <img src="https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&w=1400&q=80" alt="" style={{width:'100%',height:'100%',objectFit:'cover'}}/>
        </div>
        <div style={{background:'var(--surface-inverse)',color:'var(--text-on-dark)',padding:'70px 64px',display:'flex',flexDirection:'column',justifyContent:'center'}}>
          <div style={{marginBottom:26}}><Pill tone="dark">Portafolio de soluciones</Pill></div>
          {D.services.map((s,i)=><CategoryRow key={s.id} first={i===0} name={s.name} meta={s.meta} onClick={()=>onNavigate('servicios')}/>)}
        </div>
      </section>

      {/* ---- Flota ---- */}
      <section style={veloxSec}>
        <div style={veloxWrap}>
          <SectionHeading pill="Nuestra flota adaptable" title="El estándar VIP no depende del carro, sino del trato"
            action={<Button variant="dark" arrow onClick={()=>onNavigate('flota')}>Ver flota completa</Button>} style={{marginBottom:52}}/>
          <div style={{display:'grid',gridTemplateColumns:'repeat(2,1fr)',gap:'var(--gap-grid)'}}>
            {D.fleet.slice(0,4).map(v=><VehicleCard key={v.id} image={v.image} name={v.name} category={v.category} specs={v.specs} price={v.price} priceUnit={v.unit} footnote={v.footnote} onClick={()=>onNavigate('flota')}/>)}
          </div>
        </div>
      </section>

      {/* ---- Aliados y experiencias (equivale a la banda de marcas de la plantilla) ---- */}
      <section style={{padding:'80px 0',textAlign:'center'}}>
        <div style={veloxWrap}>
          <h4 style={{margin:'0 0 44px',fontFamily:'var(--font-display)',fontSize:20,fontWeight:700,color:'var(--text-strong)'}}>Aliados, rutas y experiencias que coordinamos</h4>
        </div>
        <Marquee speed={32} gap={80}>
          {['AEROPUERTO JMC','OLAYA HERRERA','GUATAPÉ','COMUNA 13','EJE CAFETERO','ORIENTE ANTIOQUEÑO','RUTAS GASTRONÓMICAS','BODAS &amp; EVENTOS'].map(b=>
            <span key={b} style={{fontFamily:'var(--font-display)',fontWeight:800,fontSize:24,letterSpacing:'.02em',color:'var(--grey-400)',whiteSpace:'nowrap'}}>{b}</span>)}
        </Marquee>
      </section>

      {/* ---- Cómo funciona ---- */}
      <section style={{...veloxSec,textAlign:'center',overflow:'hidden'}}>
        <div style={veloxWrap}>
          <Pill>Cómo funciona</Pill>
          <h2 style={{margin:'26px auto 60px',maxWidth:720,fontFamily:'var(--font-display)',fontSize:'var(--fs-display-2)',fontWeight:700,letterSpacing:'var(--ls-display)',lineHeight:1.12,color:'var(--text-strong)'}}>Reservado en minutos, ejecutado al detalle</h2>
          <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:'var(--gap-grid)',maxWidth:1080,margin:'0 auto'}}>
            <StepCard number="01" iconName="message-circle" title="Escríbenos">Cuéntanos vuelo, fecha, número de pasajeros y qué quieres hacer en la ciudad.</StepCard>
            <StepCard number="02" iconName="route" title="Armamos tu itinerario">Te proponemos vehículo, horarios y tarifa cerrada según tu grupo y presupuesto.</StepCard>
            <StepCard number="03" iconName="plane-landing" title="Te esperamos en la puerta">Seguimiento del vuelo, marcador personalizado y ayuda con el equipaje.</StepCard>
          </div>
        </div>
      </section>

      {/* ---- Bento ---- */}
      <section style={veloxSec}>
        <div style={veloxWrap}>
          <Eyebrow tone="gold">Por qué Velox</Eyebrow>
          <h2 style={{margin:'14px 0 56px',maxWidth:640,fontFamily:'var(--font-display)',fontSize:'var(--fs-display-2)',fontWeight:700,letterSpacing:'var(--ls-display)',lineHeight:1.12,color:'var(--text-strong)'}}>Logística resuelta, trato de anfitrión</h2>
          <div style={{display:'grid',gridTemplateColumns:'1.15fr 1fr 1fr',gap:'var(--gap-bento)'}}>
            <div style={{background:'var(--surface-card)',border:'1px solid var(--border-hairline)',borderRadius:'var(--r-2xl)',padding:28,display:'flex',flexDirection:'column'}}>
              <Marquee speed={26} gap={14} style={{borderRadius:'var(--r-md)',marginBottom:26}}>
                {D.destinations.slice(0,5).map(d=><div key={d.name} style={{position:'relative',width:190,height:150,borderRadius:'var(--r-sm)',overflow:'hidden',flex:'none'}}>
                  <img src={d.image} alt="" style={{width:'100%',height:'100%',objectFit:'cover'}}/>
                  <span style={{position:'absolute',left:0,right:0,bottom:12,textAlign:'center',color:'#fff',fontWeight:600,fontSize:15,textShadow:'0 2px 8px rgba(0,0,0,.6)'}}>{d.name}</span>
                </div>)}
              </Marquee>
              <div style={{marginBottom:22}}><Button variant="dark" arrow onClick={()=>onNavigate('servicios')}>Ver cobertura</Button></div>
              <h3 style={{margin:'6px 0 8px',fontFamily:'var(--font-display)',fontSize:20,fontWeight:700,color:'var(--text-strong)'}}>Medellín y alrededores</h3>
              <p style={{margin:0,color:'var(--text-muted)',fontSize:'var(--fs-body-sm)',maxWidth:320}}>Del aeropuerto al Oriente antioqueño, Guatapé y el Eje Cafetero.</p>
            </div>
            <FeatureCard image="https://images.unsplash.com/photo-1521791136064-7986c2920216?auto=format&fit=crop&w=900&q=80" iconName="user-check" title="Conductores de confianza">Personal verificado, presentación impecable y trato cálido paisa de alto nivel.</FeatureCard>
            <FeatureCard image="https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?auto=format&fit=crop&w=900&q=80" badge="24/7" title="Coordinación permanente">Un solo contacto por WhatsApp para todo tu itinerario, antes y durante el viaje.</FeatureCard>
            <div style={{gridColumn:'2 / span 2'}}>
              <CtaCard iconName="map-pin" title="Tu itinerario en Medellín, resuelto en una sola conversación." action={<Button variant="gold" arrow onClick={()=>onNavigate('reserva')}>Cotizar ahora</Button>}/>
            </div>
          </div>
        </div>
      </section>

      {/* ---- Stats ---- */}
      <section style={{...veloxSec,background:'var(--surface-inverse)',color:'var(--text-on-dark)',overflow:'hidden',position:'relative'}}>
        <div style={{position:'absolute',inset:0,opacity:.22}}><img src="https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=1800&q=80" alt="" style={{width:'100%',height:'100%',objectFit:'cover'}}/></div>
        <div style={{position:'absolute',inset:0,background:'var(--overlay-scrim)'}}/>
        <div style={{...veloxWrap,position:'relative',zIndex:2}}>
          <Eyebrow tone="onDarkGold">Cómo trabajamos</Eyebrow>
          <h2 style={{margin:'14px 0 64px',maxWidth:560,fontFamily:'var(--font-display)',fontSize:'var(--fs-display-2)',fontWeight:700,letterSpacing:'var(--ls-display)',lineHeight:1.12}}>Cuatro compromisos, cero improvisación</h2>
          <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:30}}>
            <StatBlock value="24/7" label="Coordinación y seguimiento de vuelos"/>
            <StatBlock value="3" label="Categorías de flota, del sedán a la van"/>
            <StatBlock value="JMC · EOH" label="Los dos aeropuertos de Medellín"/>
            <StatBlock value="100%" label="Retorno seguro garantizado en eventos"/>
          </div>
        </div>
      </section>

      {/* ---- Testimonios ---- */}
      <section style={{...veloxSec,background:'var(--surface-inverse-2)',color:'var(--text-on-dark)'}}>
        <div style={veloxWrap}>
          <div style={{display:'flex',alignItems:'flex-end',justifyContent:'space-between',gap:20,marginBottom:48,flexWrap:'wrap'}}>
            <div>
              <Eyebrow tone="onDarkGold">Lo que dicen</Eyebrow>
              <h2 style={{margin:'14px 0 0',fontFamily:'var(--font-display)',fontSize:'var(--fs-display-2)',fontWeight:700,letterSpacing:'var(--ls-display)'}}>Clientes que vuelven</h2>
            </div>
            <div style={{display:'flex',gap:12}}>
              <ArrowButton direction="left" onClick={()=>setTi(Math.max(0,ti-1))}/>
              <ArrowButton direction="right" onClick={()=>setTi(Math.min(t.length-1,ti+1))}/>
            </div>
          </div>
          <div style={{overflow:'hidden'}}>
            <div style={{display:'flex',gap:24,transition:'transform .6s var(--ease)',transform:'translateX(calc('+(-ti)+' * (33.333% + 8px)))'}}>
              {t.map((x,i)=><div key={i} style={{flex:'0 0 calc((100% - 48px)/3)'}}><TestimonialCard {...x}/></div>)}
            </div>
          </div>
        </div>
      </section>

      {/* ---- Cobertura ---- */}
      <section style={veloxSec}>
        <div style={{...veloxWrap,display:'grid',gridTemplateColumns:'1fr 1fr',gap:60,alignItems:'center'}}>
          <div style={{borderRadius:'var(--r-3xl)',overflow:'hidden',aspectRatio:'1/1',boxShadow:'var(--sh-image)'}}>
            <img src="https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=1200&q=80" alt="Guatapé" style={{width:'100%',height:'100%',objectFit:'cover'}}/>
          </div>
          <div>
            <Eyebrow tone="gold">Dónde te llevamos</Eyebrow>
            <h2 style={{margin:'14px 0 22px',maxWidth:440,fontFamily:'var(--font-display)',fontSize:'var(--fs-display-2)',fontWeight:700,letterSpacing:'var(--ls-display)',lineHeight:1.12,color:'var(--text-strong)'}}>Medellín, el Oriente y más allá</h2>
            <p style={{margin:'0 0 30px',color:'var(--text-muted)',fontSize:'var(--fs-body-lg)',maxWidth:440,lineHeight:'var(--lh-relaxed)'}}>Traslados urbanos, rutas intermunicipales y tours privados con agencias aliadas. Tarifa acordada antes de salir, siempre.</p>
            <div style={{marginBottom:40}}><Button variant="dark" arrow onClick={()=>onNavigate('reserva')}>Planear mi itinerario</Button></div>
            <div style={{fontSize:'var(--fs-body-sm)',color:'var(--text-muted)',fontWeight:600,marginBottom:16}}>Destinos frecuentes</div>
            <div style={{display:'flex',flexWrap:'wrap',gap:12}}>{D.destinations.map(d=><LocationPill key={d.name} name={d.name} image={d.image}/>)}</div>
          </div>
        </div>
      </section>

      {/* ---- FAQ ---- */}
      <section style={veloxSec}>
        <div style={{...veloxWrap,display:'grid',gridTemplateColumns:'.85fr 1.15fr',gap:56,alignItems:'start'}}>
          <div>
            <h2 style={{margin:'0 0 36px',fontFamily:'var(--font-display)',fontSize:'var(--fs-display-2)',fontWeight:700,letterSpacing:'var(--ls-display)',lineHeight:1.08,color:'var(--text-strong)'}}>Preguntas<br/>frecuentes</h2>
            <div style={{background:'var(--surface-inverse)',color:'var(--text-on-dark)',borderRadius:'var(--r-2xl)',padding:34}}>
              <span style={{width:52,height:52,borderRadius:'var(--r-circle)',border:'1px solid var(--border-gold)',display:'grid',placeItems:'center',marginBottom:26,color:'var(--text-accent-on-dark)'}}><Icon name="headset" size={24}/></span>
              <h3 style={{margin:'0 0 20px',fontFamily:'var(--font-display)',fontSize:20,fontWeight:700}}>¿No encuentras tu respuesta?</h3>
              <Button variant="light" arrow onClick={()=>onNavigate('reserva')}>Escríbenos ahora</Button>
            </div>
          </div>
          <div style={{display:'flex',flexDirection:'column',gap:14}}>
            {D.faqs.map((x,i)=><FaqItem key={i} question={x.q} open={faq===i} onToggle={()=>setFaq(faq===i?-1:i)}>{x.a}</FaqItem>)}
          </div>
        </div>
      </section>

      {/* ---- Collage con parallax ---- */}
      <CollageSection/>

      {/* ---- CTA final ---- */}
      <section style={{padding:'40px 0 120px',textAlign:'center'}}>
        <div style={veloxWrap}>
          <h2 style={{margin:'0 auto 34px',maxWidth:760,fontFamily:'var(--font-display)',fontSize:'var(--fs-display-2)',fontWeight:700,letterSpacing:'var(--ls-display)',lineHeight:1.1,color:'var(--text-strong)'}}>Cuéntanos tu vuelo y tu plan. Del resto nos encargamos.</h2>
          <Button variant="gold" size="lg" arrow onClick={()=>onNavigate('reserva')}>Reservar por WhatsApp</Button>
        </div>
      </section>
    </div>
  );
}
Object.assign(window,{HomeScreen});
