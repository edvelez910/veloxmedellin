const {Hero,Pill,Button,SectionHeading,VehicleCard,SpecChip,StatBlock,CtaCard,Eyebrow,Icon}=window.VelozVIPDesignSystem_b0ea98;
const D=window.VELOX_DATA;
const fleetWrap={maxWidth:'var(--maxw)',margin:'0 auto',padding:'0 var(--gutter)'};
const FILTERS=[{id:'all',label:'Todo'},{id:'sedan',label:'Sedán & Hatchback'},{id:'suv',label:'SUV & Camionetas'},{id:'van',label:'Vans'},{id:'bloques',label:'Por horas'}];

function FleetScreen({onNavigate}){
  const [filter,setFilter]=React.useState('all');
  const list=filter==='all'?D.fleet:D.fleet.filter(v=>v.id===filter);
  return (
    <div>
      <Hero minHeight="56vh" image="https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&w=2000&q=80" megaWord="FLOTA"
        title="Flota adaptable, servicio constante"
        subtitle="Entendemos que no todos los viajes ni todos los presupuestos son iguales. El estándar Velox no depende del carro: depende del trato y la logística."/>

      <section style={{padding:'80px 0 110px'}}>
        <div style={fleetWrap}>
          <SectionHeading eyebrow="Categorías" title="Elige por grupo, equipaje y presupuesto" style={{marginBottom:34}}/>
          <div style={{display:'flex',gap:10,flexWrap:'wrap',marginBottom:38}}>
            {FILTERS.map(x=>{
              const on=x.id===filter;
              return <button key={x.id} onClick={()=>setFilter(x.id)} style={{cursor:'pointer',fontFamily:'var(--font-sans)',fontSize:'var(--fs-body-sm)',fontWeight:500,padding:'10px 18px',borderRadius:'var(--r-pill)',
                background:on?'var(--ink-900)':'var(--surface-card)',color:on?'var(--text-on-dark)':'var(--text-body)',border:'1px solid '+(on?'var(--ink-900)':'var(--border-hairline)'),transition:'background var(--dur-fast)'}}>{x.label}</button>;
            })}
          </div>
          <div style={{display:'grid',gridTemplateColumns:'repeat(2,1fr)',gap:'var(--gap-grid)',marginBottom:60}}>
            {list.map(v=><VehicleCard key={v.id} image={v.image} name={v.name} category={v.category} specs={v.specs} price={v.price} priceUnit={v.unit} footnote={v.footnote} onClick={()=>onNavigate('reserva')}/>)}
          </div>

          <div style={{background:'var(--surface-inverse)',color:'var(--text-on-dark)',borderRadius:'var(--r-3xl)',padding:'52px 48px',marginBottom:'var(--gap-grid)'}}>
            <Eyebrow tone="onDarkGold">Incluido en toda categoría</Eyebrow>
            <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:30,marginTop:34}}>
              {[['user-check','Conductor verificado y de presentación impecable'],['radar','Seguimiento del vuelo y del trayecto'],['receipt','Tarifa cerrada acordada antes de salir'],['message-circle','Un contacto de WhatsApp para todo el itinerario']].map(([ic,txt])=>
                <div key={ic}>
                  <span style={{display:'grid',placeItems:'center',width:46,height:46,borderRadius:'var(--r-circle)',border:'1px solid var(--border-gold)',color:'var(--text-accent-on-dark)',marginBottom:16}}><Icon name={ic} size={22}/></span>
                  <p style={{margin:0,fontSize:'var(--fs-body-sm)',color:'var(--text-on-dark-muted)',lineHeight:'var(--lh-body)'}}>{txt}</p>
                </div>)}
            </div>
          </div>
          <CtaCard iconName="car-front" title="¿No sabes qué categoría necesitas? Te la recomendamos según tu grupo." action={<Button variant="gold" arrow onClick={()=>onNavigate('reserva')}>Pedir recomendación</Button>}/>
        </div>
      </section>
    </div>
  );
}
Object.assign(window,{FleetScreen});
