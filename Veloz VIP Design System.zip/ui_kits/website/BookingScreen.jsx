const {Button,Input,Select,Pill,Eyebrow,SpecChip,Icon,StarRating,QuoteCard}=window.VelozVIPDesignSystem_b0ea98;
const D=window.VELOX_DATA;
const bkWrap={maxWidth:'var(--maxw)',margin:'0 auto',padding:'0 var(--gutter)'};

function BookingScreen({onNavigate}){
  const [step,setStep]=React.useState(1);
  const [form,setForm]=React.useState({servicio:'Transfer aeropuerto → hotel',vehiculo:'SUV & Camionetas',pax:'4',vuelo:'AV 8412',fecha:'12 sep · 14:30',nombre:'',contacto:''});
  const set=k=>e=>setForm({...form,[k]:e.target.value});
  const resumen=[['Servicio',form.servicio],['Vehículo',form.vehiculo],['Pasajeros',form.pax],['Vuelo',form.vuelo||'—'],['Fecha y hora',form.fecha]];
  return (
    <div style={{background:'var(--ink-950)',minHeight:'100vh',paddingBottom:90}}>
      <div style={{position:'relative',padding:'70px 0 40px',overflow:'hidden'}}>
        <div style={{position:'absolute',inset:0,opacity:.35}}><img src="https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1800&q=80" alt="" style={{width:'100%',height:'100%',objectFit:'cover'}}/></div>
        <div style={{position:'absolute',inset:0,background:'var(--overlay-scrim)'}}/>
        <div style={{...bkWrap,position:'relative',zIndex:2,textAlign:'center'}}>
          <Eyebrow tone="onDarkGold">Reserva en 2 pasos</Eyebrow>
          <h1 style={{margin:'16px 0 14px',fontFamily:'var(--font-display)',fontSize:'clamp(34px,4.4vw,56px)',fontWeight:700,letterSpacing:'var(--ls-display)',color:'var(--text-on-dark)'}}>Cuéntanos tu plan</h1>
          <p style={{margin:'0 auto',maxWidth:520,color:'rgba(255,255,255,.72)',fontSize:'var(--fs-body-lg)',lineHeight:'var(--lh-relaxed)'}}>Sin pagos en línea: confirmamos disponibilidad y tarifa por WhatsApp antes de cerrar.</p>
        </div>
      </div>

      <div style={{...bkWrap,display:'grid',gridTemplateColumns:'1.25fr .75fr',gap:34,alignItems:'start'}}>
        <div style={{background:'var(--surface-inverse-card)',border:'1px solid var(--border-hairline-dark)',borderRadius:'var(--r-3xl)',padding:34}}>
          <div style={{display:'flex',gap:10,marginBottom:28}}>
            {[1,2].map(n=><span key={n} style={{flex:1,height:3,borderRadius:2,background:step>=n?'var(--accent)':'rgba(255,255,255,.12)'}}/>)}
          </div>
          {step===1?<>
            <h2 style={{margin:'0 0 22px',fontFamily:'var(--font-display)',fontSize:24,fontWeight:700,color:'var(--text-on-dark)'}}>1 · Tu trayecto</h2>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
              <Select tone="dark" label="Servicio" iconName="car-front" value={form.servicio} onChange={set('servicio')} options={['Transfer aeropuerto → hotel','Transfer hotel → aeropuerto','Movilidad por horas','Evento u ocasión especial','Tour privado']}/>
              <Select tone="dark" label="Vehículo" iconName="users" value={form.vehiculo} onChange={set('vehiculo')} options={D.fleet.map(v=>v.name)}/>
              <Input tone="dark" label="Pasajeros" iconName="users" value={form.pax} onChange={set('pax')}/>
              <Input tone="dark" label="Número de vuelo" iconName="plane-landing" value={form.vuelo} onChange={set('vuelo')} hint="Lo monitoreamos en tiempo real."/>
              <Input tone="dark" label="Fecha y hora" iconName="calendar" value={form.fecha} onChange={set('fecha')} style={{gridColumn:'1 / -1'}}/>
            </div>
            <div style={{display:'flex',gap:8,flexWrap:'wrap',margin:'22px 0 28px'}}>
              <SpecChip onDark iconName="shield-check">Conductor verificado</SpecChip>
              <SpecChip onDark iconName="receipt">Tarifa cerrada</SpecChip>
              <SpecChip onDark iconName="clock">Espera incluida 60 min</SpecChip>
            </div>
            <Button variant="gold" arrow onClick={()=>setStep(2)}>Continuar</Button>
          </>:step===2?<>
            <h2 style={{margin:'0 0 22px',fontFamily:'var(--font-display)',fontSize:24,fontWeight:700,color:'var(--text-on-dark)'}}>2 · Tus datos</h2>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
              <Input tone="dark" label="Nombre y apellido" iconName="user" placeholder="Laura Restrepo" value={form.nombre} onChange={set('nombre')}/>
              <Input tone="dark" label="WhatsApp o correo" iconName="message-circle" placeholder="+57 300 000 0000" value={form.contacto} onChange={set('contacto')}/>
              <Input tone="dark" label="Notas del itinerario" iconName="route" placeholder="Silla para bebé, dos paradas, conductor bilingüe…" style={{gridColumn:'1 / -1'}}/>
            </div>
            <div style={{display:'flex',gap:12,marginTop:28,flexWrap:'wrap'}}>
              <Button variant="gold" arrow onClick={()=>setStep(3)}>Enviar solicitud</Button>
              <Button variant="ghost" onClick={()=>setStep(1)}>Volver</Button>
            </div>
          </>:<>
            <span style={{display:'grid',placeItems:'center',width:64,height:64,borderRadius:'var(--r-circle)',background:'var(--accent)',color:'var(--ink-900)',marginBottom:22}}><Icon name="check" size={30}/></span>
            <h2 style={{margin:'0 0 12px',fontFamily:'var(--font-display)',fontSize:26,fontWeight:700,color:'var(--text-on-dark)'}}>Solicitud recibida</h2>
            <p style={{margin:'0 0 26px',color:'var(--text-on-dark-muted)',fontSize:'var(--fs-body-lg)',lineHeight:'var(--lh-relaxed)',maxWidth:420}}>Te escribimos por WhatsApp en menos de 30 minutos con la confirmación y la tarifa cerrada. Si tu vuelo cambia, nosotros ajustamos.</p>
            <div style={{display:'flex',gap:12,flexWrap:'wrap'}}>
              <Button variant="gold" iconName="message-circle">Abrir WhatsApp</Button>
              <Button variant="ghost" onClick={()=>{setStep(1);onNavigate('home');}}>Volver al inicio</Button>
            </div>
          </>}
        </div>

        <div style={{display:'flex',flexDirection:'column',gap:18}}>
          <div style={{background:'var(--surface-inverse-2)',border:'1px solid var(--border-hairline-dark)',borderRadius:'var(--r-2xl)',padding:26}}>
            <Eyebrow tone="onDarkGold">Resumen</Eyebrow>
            <div style={{marginTop:18}}>
              {resumen.map(([k,v])=><div key={k} style={{display:'flex',justifyContent:'space-between',gap:14,padding:'11px 0',borderBottom:'1px solid var(--border-hairline-dark)'}}>
                <span style={{fontSize:'var(--fs-caption)',color:'var(--text-on-dark-faint)'}}>{k}</span>
                <span style={{fontSize:'var(--fs-body-sm)',color:'var(--text-on-dark)',fontWeight:500,textAlign:'right'}}>{v}</span>
              </div>)}
            </div>
            <p style={{margin:'18px 0 0',fontSize:'var(--fs-micro)',color:'var(--text-on-dark-faint)'}}>La tarifa se confirma por WhatsApp según itinerario y disponibilidad.</p>
          </div>
          <div style={{background:'var(--surface-inverse-card)',border:'1px solid var(--border-hairline-dark)',borderRadius:'var(--r-2xl)',padding:26,color:'var(--text-on-dark)'}}>
            <StarRating value={5}/>
            <p style={{margin:'14px 0 12px',fontSize:'var(--fs-body-sm)',color:'rgba(255,255,255,.82)',lineHeight:'var(--lh-body)'}}>“El vuelo llegó dos horas tarde y el conductor seguía ahí, con el marcador en la mano.”</p>
            <b style={{fontFamily:'var(--font-display)',fontSize:16}}>Laura Restrepo</b>
          </div>
          <div style={{display:'flex',alignItems:'center',gap:12,padding:'16px 20px',border:'1px solid var(--border-gold)',borderRadius:'var(--r-xl)',color:'var(--text-accent-on-dark)'}}>
            <Icon name="phone" size={20}/>
            <span style={{fontSize:'var(--fs-body-sm)'}}>+57 300 000 0000 · 24/7</span>
          </div>
        </div>
      </div>
    </div>
  );
}
Object.assign(window,{BookingScreen});
