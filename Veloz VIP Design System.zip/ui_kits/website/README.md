# UI kit — Sitio web Velox VIP Services

Recreación click-through del sitio público, construida sobre los componentes del design system
(`window.VelozVIPDesignSystem_b0ea98`) y la estructura de la plantilla entregada por el cliente
(`uploads/plantilla pagina web.html` — tema "Carent", Webestica/Framer).

## Pantallas
| Archivo | Vista | Notas |
|---|---|---|
| `HomeScreen.jsx` | Inicio | Hero full-bleed, quiénes somos + pilares + marquee, panel partido de servicios, flota, cómo funciona, bento, banda de compromisos, testimonios, cobertura, FAQ, CTA |
| `ServicesScreen.jsx` | Servicios | Selector de 4 servicios con panel de detalle, bento de sub-servicios, cobertura |
| `FleetScreen.jsx` | Flota | Filtros por categoría, grid de `VehicleCard`, panel "incluido en toda categoría" |
| `BookingScreen.jsx` | Reservar | Formulario en 2 pasos + confirmación, resumen lateral pegado, sin pago en línea |
| `data.js` | — | Todo el contenido (flota, servicios, destinos, testimonios, FAQ) |

## Interacción
`index.html` monta `Site`, que gobierna la navegación entre las 4 pantallas, el estado
`scrolled` del nav y el scroll-to-top. Cada pantalla recibe `onNavigate(id)`.

## Diferencias respecto a la plantilla original
La plantilla es de renta de autos (precios /día, marcas de fábrica, sedes mundiales). Velox no
renta vehículos: vende trayectos e itinerarios. Por eso las tarifas son "Desde … / trayecto"
u "/hora", la banda de marcas se reemplazó por compromisos de servicio, y la reserva no cobra
en línea — confirma por WhatsApp. La estructura, radios, sombras y ritmo vertical son los de la
plantilla; el color y la tipografía son los de la marca Velox.

## Fotografía
Las imágenes son placeholders de Unsplash. **Reemplazar por fotos reales de la flota, conductores
y Medellín antes de publicar** — la identidad depende de fotografía cálida y oscura, no de stock genérico.
