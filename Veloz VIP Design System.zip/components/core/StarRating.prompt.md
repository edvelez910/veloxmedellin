Stars are brand gold (#c9a96b), never yellow.

```jsx
<StarRating value={4.9} showValue />
```
