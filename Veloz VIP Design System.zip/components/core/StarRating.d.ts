/** Gold ★ rating row; supports halves via fractional values. */
export interface StarRatingProps {
  value?: number;
  max?: number;
  size?: number;
  showValue?: boolean;
  style?: React.CSSProperties;
}
export declare function StarRating(props: StarRatingProps): JSX.Element;
