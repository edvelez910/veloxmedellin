Spec metadata inside `VehicleCard`; 3 per card maximum.

```jsx
<SpecChip iconName="users">4 pasajeros</SpecChip>
```
