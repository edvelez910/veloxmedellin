Brand signature for navs, footers and slide corners. Set `assetBase` to wherever you copied `assets/`.

```jsx
<BrandLockup variant="onDark" size={30} assetBase="assets" />
```

`showWordmark={false}` gives the star alone (favicons, tight navs). The wordmark is a PNG — never set VELOX in live type, the logo's serif is not a licensed webfont here.
