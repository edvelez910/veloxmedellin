/** Lucide icon glyph tinted with currentColor. */
export interface IconProps {
  /** Lucide icon name in kebab-case, e.g. "plane-landing", "clock", "shield-check". */
  name?: string;
  /** Square size in px. Veloz uses 17 in pills, 20 inline, 32 in ring badges, 38 in feature rows. */
  size?: number;
  style?: React.CSSProperties;
}
export declare function Icon(props: IconProps): JSX.Element;
