/**
 * The supplied Velox logo, at the right size for inline use. Intentional addition: an asset
 * wrapper so the mark and wordmark are never re-drawn or re-typeset by hand.
 */
export interface BrandLockupProps {
  /** onDark = white-wordmark file (default) · onLight = ink-wordmark file. */
  variant?: 'onDark' | 'onLight';
  /** Star height in px. With showWordmark the full lockup renders at 1.55× this value. */
  size?: number;
  showWordmark?: boolean;
  /** Relative path to the design system's assets/ folder from the consuming page. */
  assetBase?: string;
  style?: React.CSSProperties;
}
export declare function BrandLockup(props: BrandLockupProps): JSX.Element;
