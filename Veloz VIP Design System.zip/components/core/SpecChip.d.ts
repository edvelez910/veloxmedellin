/** Icon + value chip for vehicle specs. */
export interface SpecChipProps {
  iconName?: string;
  children?: React.ReactNode;
  onDark?: boolean;
  style?: React.CSSProperties;
}
export declare function SpecChip(props: SpecChipProps): JSX.Element;
