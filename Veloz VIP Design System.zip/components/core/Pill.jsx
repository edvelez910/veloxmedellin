import React from 'react';
import {Icon} from './Icon.jsx';

const veloxPillTones={
  light:{background:'var(--grey-050)',border:'1px solid var(--border-hairline)',color:'var(--ink-600)',boxShadow:'var(--sh-hairline)'},
  dark:{background:'var(--ink-800)',border:'1px solid var(--border-hairline-dark)',color:'var(--text-on-dark)'},
  glass:{background:'var(--glass-dark)',border:'1px solid var(--border-glass)',color:'var(--text-on-dark)',backdropFilter:'var(--blur-glass)'},
  gold:{background:'var(--surface-gold-soft)',border:'1px solid var(--border-gold)',color:'var(--gold-800)'}
};

/** Small label capsule: section eyebrows, hero badges, live status. */
export function Pill({children,tone='light',iconName,dot=false,style,...rest}){
  return (
    <span style={{display:'inline-flex',alignItems:'center',gap:'8px',padding:'8px 16px',borderRadius:'var(--r-pill)',fontFamily:'var(--font-sans)',fontSize:'var(--fs-body-sm)',fontWeight:'var(--fw-medium)',...veloxPillTones[tone],...style}} {...rest}>
      {dot&&<span style={{width:7,height:7,borderRadius:'50%',background:'var(--status-live)',boxShadow:'var(--sh-live-ring)',flex:'none'}}/>}
      {iconName&&<Icon name={iconName} size={17}/>}
      {children}
    </span>
  );
}
