import React from 'react';

/** The Velox mark + wordmark. Always the supplied logo files — the wordmark is never re-typeset. */
export function BrandLockup({variant='onDark',size=30,showWordmark=true,assetBase='../../assets',style,...rest}){
  const file=showWordmark
    ? (variant==='onDark'?'/logo-velox-lockup-white.png':'/logo-velox-lockup.png')
    : '/mark-velox-star.png';
  return (
    <span style={{display:'inline-flex',alignItems:'center',...style}} {...rest}>
      <img src={assetBase+file} alt="Velox VIP Services" style={{height:showWordmark?size*1.55:size,width:'auto',display:'block'}}/>
    </span>
  );
}
