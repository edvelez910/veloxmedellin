Capsule label — opens most sections and floats over the hero.

```jsx
<Pill tone="glass" iconName="clock">Seguimiento de vuelo en tiempo real</Pill>
<Pill dot>Conductor en ruta</Pill>
```
