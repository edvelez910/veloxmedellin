/** Section opener: eyebrow or pill, display headline, optional lead and right-aligned action. */
export interface SectionHeadingProps {
  /** Uppercase kicker (Eyebrow). Use this or `pill`, never both. */
  eyebrow?: React.ReactNode;
  /** Capsule kicker (Pill) — the template's alternate treatment. */
  pill?: React.ReactNode;
  title?: React.ReactNode;
  lead?: React.ReactNode;
  /** Usually a <Button variant="dark" arrow>. */
  action?: React.ReactNode;
  align?: 'left' | 'center';
  /** Set on ink surfaces. */
  onDark?: boolean;
  style?: React.CSSProperties;
}
export declare function SectionHeading(props: SectionHeadingProps): JSX.Element;
