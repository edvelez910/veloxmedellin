Circular arrow for carousels. Hover fills 10% white, press scales to .94.

```jsx
<ArrowButton direction="left" onClick={prev} />
```
