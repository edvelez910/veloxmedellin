import React from 'react';
import {Icon} from './Icon.jsx';

const veloxBtnBase={display:'inline-flex',alignItems:'center',gap:'10px',border:'none',cursor:'pointer',fontFamily:'var(--font-sans)',fontWeight:'var(--fw-semibold)',borderRadius:'var(--r-pill)',whiteSpace:'nowrap',textDecoration:'none',transition:'transform var(--dur-slow) var(--ease),background var(--dur-fast),color var(--dur-fast),box-shadow var(--dur-slow) var(--ease)'};
const veloxBtnSizes={sm:{padding:'11px 22px',fontSize:'14px'},md:{padding:'15px 26px',fontSize:'15px'},lg:{padding:'17px 30px',fontSize:'15px'}};
const veloxBtnVariants={
  gold:{background:'var(--accent)',color:'var(--text-on-gold)',boxShadow:'var(--sh-gold)'},
  dark:{background:'var(--ink-900)',color:'var(--text-on-dark)'},
  light:{background:'var(--grey-050)',color:'var(--text-body)',boxShadow:'var(--sh-sm)'},
  ghost:{background:'rgba(255,255,255,.08)',color:'var(--text-on-dark)',border:'1px solid var(--border-glass)',backdropFilter:'var(--blur-glass)'},
  outlineGold:{background:'transparent',color:'var(--text-accent)',border:'1px solid var(--border-gold)'}
};
const veloxBtnHover={
  gold:{background:'var(--gold-400)',transform:'translateY(var(--lift-sm))',boxShadow:'0 18px 44px rgba(201,169,107,.38)'},
  dark:{background:'#000',transform:'translateY(var(--lift-sm))'},
  light:{transform:'translateY(var(--lift-sm))',boxShadow:'var(--sh-md)'},
  ghost:{background:'rgba(255,255,255,.16)'},
  outlineGold:{background:'rgba(201,169,107,.10)',borderColor:'var(--accent)'}
};

/** Pill CTA. Gold is the primary action; dark/light/ghost carry secondary weight. */
export function Button({children,variant='gold',size='md',icon,iconName,arrow=false,disabled=false,href,onClick,style,...rest}){
  const [hover,setHover]=React.useState(false);
  const Tag=href?'a':'button';
  const css={...veloxBtnBase,...veloxBtnSizes[size],...veloxBtnVariants[variant],...(hover&&!disabled?veloxBtnHover[variant]:null),
    ...(disabled?{opacity:.42,cursor:'not-allowed',boxShadow:'none',transform:'none'}:null),...style};
  return (
    <Tag href={href} onClick={disabled?undefined:onClick} disabled={Tag==='button'?disabled:undefined} style={css}
      onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)} {...rest}>
      {iconName?<Icon name={iconName} size={size==='sm'?16:18}/>:icon}
      <span>{children}</span>
      {arrow&&<span style={{display:'inline-flex',transition:'transform var(--dur-slow) var(--ease)',transform:hover&&!disabled?'translateX(5px)':'none'}}>→</span>}
    </Tag>
  );
}
