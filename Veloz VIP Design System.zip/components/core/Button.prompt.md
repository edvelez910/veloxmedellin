The one CTA primitive — always a full pill, never a square button.

```jsx
<Button variant="gold" arrow>Reservar por WhatsApp</Button>
<Button variant="ghost" size="sm" iconName="phone">Llámanos</Button>
```

One gold button per view; everything else is `dark` (on light surfaces), `light`/`ghost` (on dark or imagery) or `outlineGold`. Hover lifts 3px; the arrow slides 5px.
