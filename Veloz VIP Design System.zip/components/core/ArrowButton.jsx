import React from 'react';
import {Icon} from './Icon.jsx';

/** 48px circular icon button — carousel arrows, quiet inline actions. */
export function ArrowButton({direction='right',iconName,onDark=true,label,onClick,style,...rest}){
  const [hover,setHover]=React.useState(false);
  const [press,setPress]=React.useState(false);
  return <button aria-label={label||direction} onClick={onClick}
    onMouseEnter={()=>setHover(true)} onMouseLeave={()=>{setHover(false);setPress(false);}}
    onMouseDown={()=>setPress(true)} onMouseUp={()=>setPress(false)}
    style={{width:48,height:48,borderRadius:'var(--r-circle)',display:'grid',placeItems:'center',cursor:'pointer',
      background:hover?(onDark?'rgba(255,255,255,.10)':'var(--surface-sunken)'):'transparent',
      border:onDark?'1px solid var(--border-glass)':'1px solid var(--border-hairline)',
      color:onDark?'var(--text-on-dark)':'var(--text-body)',
      transform:press?'scale(var(--press-scale))':'none',
      transition:'background var(--dur-fast),transform var(--dur-fast)',...style}} {...rest}>
    <Icon name={iconName||(direction==='left'?'chevron-left':'chevron-right')} size={20}/>
  </button>;
}
