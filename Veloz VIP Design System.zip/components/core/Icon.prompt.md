Lucide glyph masked with `currentColor` — the only icon primitive in the system; never hand-draw an SVG.

```jsx
<Icon name="plane-landing" size={20} />
```

Common Velox glyphs: `plane-landing` (transfers), `clock` (24/7 · seguimiento), `shield-check` (seguridad), `car-front` / `bus` (flota), `map-pin` (Medellín · rutas), `utensils` (reservas), `calendar`, `users`, `briefcase`, `phone`, `message-circle` (WhatsApp), `arrow-right`. Colour comes from the parent's `color`.
