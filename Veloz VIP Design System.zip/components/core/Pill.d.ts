/** Label capsule used for section eyebrows, hero badges and live status. */
export interface PillProps {
  children?: React.ReactNode;
  /** light on page surfaces · dark on ink panels · glass over imagery · gold for accented labels. */
  tone?: 'light' | 'dark' | 'glass' | 'gold';
  iconName?: string;
  /** Green live dot with a 4px ring — "seguimiento en vivo". */
  dot?: boolean;
  style?: React.CSSProperties;
}
export declare function Pill(props: PillProps): JSX.Element;
