/** Uppercase, wide-tracked kicker above a heading. */
export interface EyebrowProps {
  children?: React.ReactNode;
  tone?: 'muted' | 'gold' | 'onDark' | 'onDarkGold';
  style?: React.CSSProperties;
}
export declare function Eyebrow(props: EyebrowProps): JSX.Element;
