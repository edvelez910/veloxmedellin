Every section starts with one of these — never a bare `<h2>`.

```jsx
<SectionHeading pill="Nuestra flota" title="Elige el vehículo de tu viaje"
  action={<Button variant="dark" arrow>Ver flota completa</Button>} />
```
