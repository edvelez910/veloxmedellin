import React from 'react';
import {Icon} from './Icon.jsx';

/** Small spec chip inside vehicle cards: pasajeros, transmisión, maletas. */
export function SpecChip({iconName,children,onDark=false,style,...rest}){
  return <span style={{display:'inline-flex',alignItems:'center',gap:'7px',padding:'8px 13px',borderRadius:'var(--r-pill)',fontFamily:'var(--font-sans)',fontSize:'var(--fs-caption)',fontWeight:'var(--fw-medium)',
    background:onDark?'rgba(255,255,255,.06)':'var(--surface-sunken)',border:onDark?'1px solid var(--border-hairline-dark)':'1px solid var(--border-hairline)',color:onDark?'var(--text-on-dark-muted)':'var(--ink-600)',...style}} {...rest}>
    {iconName&&<Icon name={iconName} size={15}/>}{children}
  </span>;
}
