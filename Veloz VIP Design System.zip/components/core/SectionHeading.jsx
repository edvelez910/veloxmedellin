import React from 'react';
import {Eyebrow} from './Eyebrow.jsx';
import {Pill} from './Pill.jsx';

/** Eyebrow (or pill) + display headline, optionally with an action on the right. */
export function SectionHeading({eyebrow,pill,title,lead,action,align='left',onDark=false,style,...rest}){
  const dark=onDark;
  return (
    <div style={{display:'flex',alignItems:'flex-end',justifyContent:'space-between',gap:'20px',flexWrap:'wrap',textAlign:align,...style}} {...rest}>
      <div style={{maxWidth:'760px',margin:align==='center'?'0 auto':undefined}}>
        {pill&&<div style={{marginBottom:'18px'}}><Pill tone={dark?'dark':'light'}>{pill}</Pill></div>}
        {eyebrow&&<div style={{marginBottom:'14px'}}><Eyebrow tone={dark?'onDarkGold':'gold'}>{eyebrow}</Eyebrow></div>}
        <h2 style={{margin:0,fontFamily:'var(--font-display)',fontSize:'var(--fs-display-2)',fontWeight:'var(--fw-bold)',lineHeight:'var(--lh-display)',letterSpacing:'var(--ls-display)',color:dark?'var(--text-on-dark)':'var(--text-strong)'}}>{title}</h2>
        {lead&&<p style={{margin:'18px 0 0',fontFamily:'var(--font-sans)',fontSize:'var(--fs-body-lg)',lineHeight:'var(--lh-relaxed)',color:dark?'var(--text-on-dark-muted)':'var(--text-muted)',maxWidth:'560px',marginInline:align==='center'?'auto':undefined}}>{lead}</p>}
      </div>
      {action}
    </div>
  );
}
