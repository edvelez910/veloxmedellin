Inter, uppercase, 0.18em tracking — the typographic echo of "VIP SERVICES" in the logo.

```jsx
<Eyebrow tone="gold">Movilidad privada en Medellín</Eyebrow>
```
