import React from 'react';

/** Wide-tracked uppercase kicker, borrowed from the "VIP SERVICES" lockup. */
export function Eyebrow({children,tone='muted',style,...rest}){
  const colors={muted:'var(--text-muted)',gold:'var(--text-accent)',onDark:'var(--text-on-dark-muted)',onDarkGold:'var(--text-accent-on-dark)'};
  return <span style={{display:'block',fontFamily:'var(--font-caps)',fontSize:'12.5px',fontWeight:'var(--fw-medium)',letterSpacing:'var(--ls-caps)',textTransform:'uppercase',color:colors[tone],...style}} {...rest}>{children}</span>;
}
