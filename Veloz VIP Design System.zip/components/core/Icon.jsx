import React from 'react';

const LUCIDE='https://unpkg.com/lucide-static@0.436.0/icons/';
const veloxIconCache={};

/** Lucide glyph injected as real SVG so it inherits currentColor. */
export function Icon({name='arrow-right',size=20,style,...rest}){
  const [markup,setMarkup]=React.useState(veloxIconCache[name]||null);
  React.useEffect(()=>{
    if(veloxIconCache[name]){setMarkup(veloxIconCache[name]);return;}
    let live=true;
    fetch(LUCIDE+name+'.svg').then(r=>r.ok?r.text():'').then(t=>{
      if(!t)return;
      const svg=t.replace(/<\?xml[^>]*\?>/g,'').replace(/width="24"/,'width="100%"').replace(/height="24"/,'height="100%"');
      veloxIconCache[name]=svg;
      if(live)setMarkup(svg);
    }).catch(()=>{});
    return ()=>{live=false;};
  },[name]);
  return <span aria-hidden="true" style={{display:'inline-flex',alignItems:'center',justifyContent:'center',width:size,height:size,flex:'none',color:'inherit',...style}}
    dangerouslySetInnerHTML={markup?{__html:markup}:undefined} {...rest}/>;
}
