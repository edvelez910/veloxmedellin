/** Circular 48px icon button (carousel navigation). */
export interface ArrowButtonProps {
  direction?: 'left' | 'right';
  /** Override the chevron with any Lucide name. */
  iconName?: string;
  onDark?: boolean;
  label?: string;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
export declare function ArrowButton(props: ArrowButtonProps): JSX.Element;
