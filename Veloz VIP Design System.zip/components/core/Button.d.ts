/**
 * Pill call-to-action.
 */
export interface ButtonProps {
  children?: React.ReactNode;
  /** gold = primary. dark/light = secondary on the opposite surface. ghost = over imagery. outlineGold = quiet. */
  variant?: 'gold' | 'dark' | 'light' | 'ghost' | 'outlineGold';
  /** sm 11/22 · md 15/26 (default) · lg 17/30 */
  size?: 'sm' | 'md' | 'lg';
  /** Lucide name rendered before the label. */
  iconName?: string;
  /** Custom node before the label (use instead of iconName). */
  icon?: React.ReactNode;
  /** Trailing → that slides 5px right on hover. */
  arrow?: boolean;
  disabled?: boolean;
  href?: string;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
export declare function Button(props: ButtonProps): JSX.Element;
