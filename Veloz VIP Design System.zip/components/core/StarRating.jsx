import React from 'react';

/** Gold rating stars (★ glyphs — the brand never uses a yellow star). */
export function StarRating({value=5,max=5,size=17,showValue=false,style,...rest}){
  const stars=[];
  for(let i=0;i<max;i++){
    const filled=value-i;
    stars.push(<span key={i} style={{position:'relative',display:'inline-block',color:'rgba(201,169,107,.28)',fontSize:size+'px',lineHeight:1}}>
      ★<span style={{position:'absolute',inset:0,overflow:'hidden',width:(Math.max(0,Math.min(1,filled))*100)+'%',color:'var(--status-star)'}}>★</span>
    </span>);
  }
  return <span style={{display:'inline-flex',alignItems:'center',gap:'3px',...style}} {...rest}>
    {stars}
    {showValue&&<span style={{marginLeft:'8px',fontFamily:'var(--font-sans)',fontSize:'var(--fs-caption)',fontWeight:'var(--fw-semibold)',color:'inherit'}}>{value.toFixed(1)}</span>}
  </span>;
}
