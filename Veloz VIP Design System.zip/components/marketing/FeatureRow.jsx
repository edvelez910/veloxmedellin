import React from 'react';
import {Icon} from '../core/Icon.jsx';

/** Centred icon + two-line label, used in the trio under the about lead. */
export function FeatureRow({iconName,children,onDark=false,style,...rest}){
  return (
    <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:'14px',maxWidth:190,textAlign:'center',
      fontFamily:'var(--font-sans)',fontWeight:'var(--fw-medium)',fontSize:'var(--fs-body-sm)',lineHeight:'var(--lh-snug)',
      color:onDark?'var(--text-on-dark-muted)':'var(--ink-600)',...style}} {...rest}>
      <span style={{width:52,height:52,display:'grid',placeItems:'center',color:onDark?'var(--text-accent-on-dark)':'var(--text-accent)'}}>
        <Icon name={iconName} size={38}/>
      </span>
      {children}
    </div>
  );
}
