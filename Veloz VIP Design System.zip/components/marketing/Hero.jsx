import React from 'react';

/** Full-bleed photo hero: ghost mega word, glass badges, display headline, CTA row. */
export function Hero({image,megaWord,title,subtitle,badges,actions,minHeight='100vh',style,...rest}){
  return (
    <header style={{position:'relative',minHeight,display:'flex',flexDirection:'column',justifyContent:'flex-end',overflow:'hidden',background:'var(--ink-950)',...style}} {...rest}>
      <div style={{position:'absolute',inset:0,zIndex:0}}>
        {image&&<img src={image} alt="" style={{width:'100%',height:'100%',objectFit:'cover'}}/>}
        <div style={{position:'absolute',inset:0,background:'var(--overlay-hero)'}}/>
      </div>
      {megaWord&&<div aria-hidden="true" style={{position:'absolute',top:'10%',left:0,right:0,zIndex:1,textAlign:'center',fontFamily:'var(--font-display)',fontWeight:'var(--fw-black)',
        color:'rgba(201,169,107,.30)',fontSize:'var(--fs-mega)',letterSpacing:'var(--ls-mega)',lineHeight:.9,whiteSpace:'nowrap',userSelect:'none'}}>{megaWord}</div>}
      <div style={{position:'relative',zIndex:2,maxWidth:'var(--maxw)',margin:'0 auto',padding:'0 var(--gutter) 64px',width:'100%'}}>
        {badges&&<div style={{display:'flex',gap:'14px',justifyContent:'center',marginBottom:'26px',flexWrap:'wrap'}}>{badges}</div>}
        <h1 style={{margin:'0 0 18px',textAlign:'center',fontFamily:'var(--font-display)',fontSize:'var(--fs-display-1)',fontWeight:'var(--fw-bold)',letterSpacing:'var(--ls-display)',lineHeight:'var(--lh-display)',color:'var(--text-on-dark)'}}>{title}</h1>
        {subtitle&&<p style={{margin:'0 auto 34px',maxWidth:620,textAlign:'center',fontFamily:'var(--font-sans)',fontSize:'var(--fs-body-lg)',lineHeight:'var(--lh-relaxed)',color:'rgba(255,255,255,.78)'}}>{subtitle}</p>}
        {actions&&<div style={{display:'flex',justifyContent:'center',gap:'14px',flexWrap:'wrap'}}>{actions}</div>}
      </div>
    </header>
  );
}
