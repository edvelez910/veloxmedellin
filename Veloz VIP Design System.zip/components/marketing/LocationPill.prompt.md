Coverage list: Guatapé, Comuna 13, Eje Cafetero, Oriente antioqueño.

```jsx
<LocationPill name="Guatapé" image="/img/guatape.jpg" />
```
