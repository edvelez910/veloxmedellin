import React from 'react';

/** Destination capsule with a round thumbnail. */
export function LocationPill({name,image,style,...rest}){
  return <span style={{display:'inline-flex',alignItems:'center',gap:'9px',background:'var(--surface-card)',border:'1px solid var(--border-hairline)',padding:'9px 16px 9px 9px',borderRadius:'var(--r-pill)',fontFamily:'var(--font-sans)',fontSize:'var(--fs-body-sm)',fontWeight:'var(--fw-medium)',color:'var(--text-body)',boxShadow:'var(--sh-hairline)',...style}} {...rest}>
    {image&&<img src={image} alt="" style={{width:26,height:26,borderRadius:'var(--r-circle)',objectFit:'cover'}}/>}
    {name}
  </span>;
}
