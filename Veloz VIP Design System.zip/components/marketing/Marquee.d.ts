/** Infinite scrolling row with faded edges; children are duplicated automatically. */
export interface MarqueeProps {
  children?: React.ReactNode;
  /** Seconds per loop — 18 fast, 32 base, 40 slow. */
  speed?: number;
  gap?: number;
  fadeEdges?: boolean;
  reverse?: boolean;
  style?: React.CSSProperties;
}
export declare function Marquee(props: MarqueeProps): JSX.Element;
