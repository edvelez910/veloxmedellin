/**
 * Full-bleed hero with a ghosted gold word behind the headline.
 */
export interface HeroProps {
  image?: string;
  /** Oversized translucent gold word behind the content, e.g. "MEDELLÍN". */
  megaWord?: string;
  title?: React.ReactNode;
  subtitle?: React.ReactNode;
  /** Row of <Pill tone="glass"> badges. */
  badges?: React.ReactNode;
  /** Row of <Button>. */
  actions?: React.ReactNode;
  minHeight?: string;
  style?: React.CSSProperties;
}
export declare function Hero(props: HeroProps): JSX.Element;
