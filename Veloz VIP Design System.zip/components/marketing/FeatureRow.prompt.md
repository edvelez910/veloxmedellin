The four Velox pillars: puntualidad, seguridad, seguimiento, soluciones a medida.

```jsx
<FeatureRow iconName="shield-check">Seguridad<br/>absoluta</FeatureRow>
```
