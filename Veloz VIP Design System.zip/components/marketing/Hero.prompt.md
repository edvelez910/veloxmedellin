Opens the site. Content is bottom-anchored and centred over a dark-graded photograph.

```jsx
<Hero image="/img/medellin.jpg" megaWord="MEDELLÍN" title={<>Tu tranquilidad,<br/>nuestra ruta.</>}
  badges={<><Pill tone="glass" iconName="plane-landing">Seguimiento de vuelo</Pill></>}
  actions={<Button variant="gold" arrow>Reservar por WhatsApp</Button>} />
```
