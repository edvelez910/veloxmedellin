/** Destination chip with a 26px round thumbnail. */
export interface LocationPillProps {
  name?: React.ReactNode;
  image?: string;
  style?: React.CSSProperties;
}
export declare function LocationPill(props: LocationPillProps): JSX.Element;
