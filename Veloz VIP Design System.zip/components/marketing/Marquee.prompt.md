The brand's one piece of ambient motion: photo strips, ally logos, service tags.

```jsx
<Marquee speed={40} gap={20}>
  {photos.map(src=><img key={src} src={src} style={{width:300,height:200,objectFit:'cover',borderRadius:'var(--r-lg)'}}/>)}
</Marquee>
```
