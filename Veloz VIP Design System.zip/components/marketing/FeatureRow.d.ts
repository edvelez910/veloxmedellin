/** Icon-over-label pillar; place 3–4 in a centred flex row with 60px gaps. */
export interface FeatureRowProps {
  iconName?: string;
  children?: React.ReactNode;
  onDark?: boolean;
  style?: React.CSSProperties;
}
export declare function FeatureRow(props: FeatureRowProps): JSX.Element;
