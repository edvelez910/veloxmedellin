import React from 'react';

/** Edge-masked infinite horizontal track — photo strips, allies, text bands. */
export function Marquee({children,speed=32,gap=20,fadeEdges=true,reverse=false,style,...rest}){
  const items=React.Children.toArray(children);
  const mask='linear-gradient(90deg,transparent,#000 8%,#000 92%,transparent)';
  const kf='velox-marquee-'+(reverse?'rev':'fwd');
  return (
    <div style={{overflow:'hidden',WebkitMaskImage:fadeEdges?mask:undefined,maskImage:fadeEdges?mask:undefined,...style}} {...rest}>
      <style>{'@keyframes velox-marquee-fwd{to{transform:translateX(-50%)}}@keyframes velox-marquee-rev{from{transform:translateX(-50%)}to{transform:none}}'}</style>
      <div style={{display:'flex',gap:gap+'px',width:'max-content',animation:kf+' '+speed+'s linear infinite'}}>
        {items}{items}
      </div>
    </div>
  );
}
