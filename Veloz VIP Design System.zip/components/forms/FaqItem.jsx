import React from 'react';

/** Accordion row. Controlled via `open`/`onToggle`, or self-managed. */
export function FaqItem({question,children,open,defaultOpen=false,onToggle,style,...rest}){
  const [internal,setInternal]=React.useState(defaultOpen);
  const isOpen=open!==undefined?open:internal;
  const toggle=()=>{onToggle?onToggle(!isOpen):setInternal(!isOpen);};
  return (
    <div style={{background:'var(--surface-card)',border:'1px solid '+(isOpen?'var(--border-gold)':'var(--border-hairline)'),borderRadius:'var(--r-lg)',overflow:'hidden',transition:'border-color var(--dur-fast)',...style}} {...rest}>
      <div onClick={toggle} style={{display:'flex',alignItems:'center',justifyContent:'space-between',gap:'20px',padding:'24px 26px',cursor:'pointer',
        fontFamily:'var(--font-display)',fontSize:'19px',fontWeight:'var(--fw-semibold)',color:'var(--text-strong)'}}>
        <span>{question}</span>
        <span style={{width:32,height:32,borderRadius:'var(--r-circle)',flex:'none',display:'grid',placeItems:'center',position:'relative',
          background:isOpen?'var(--accent)':'var(--surface-sunken)',transition:'background var(--dur-fast)'}}>
          <span style={{position:'absolute',width:13,height:2,borderRadius:2,background:isOpen?'var(--ink-900)':'var(--ink-900)'}}/>
          <span style={{position:'absolute',width:2,height:13,borderRadius:2,background:isOpen?'var(--ink-900)':'var(--ink-900)',transform:isOpen?'scaleY(0)':'none',transition:'transform var(--dur-base) var(--ease)'}}/>
        </span>
      </div>
      <div style={{maxHeight:isOpen?'400px':'0',overflow:'hidden',transition:'max-height .45s var(--ease)'}}>
        <p style={{margin:0,padding:'0 26px 26px',fontFamily:'var(--font-sans)',fontSize:'var(--fs-body)',lineHeight:'var(--lh-relaxed)',color:'var(--text-muted)',maxWidth:560}}>{children}</p>
      </div>
    </div>
  );
}
