Sits under the brand lockup in the footer.

```jsx
<NewsletterCard title="Tarifas y disponibilidad" description="Recibe tarifas de temporada y cupos de eventos."
  buttonLabel="Quiero saber" note="Te respondemos en menos de 24 horas." />
```
