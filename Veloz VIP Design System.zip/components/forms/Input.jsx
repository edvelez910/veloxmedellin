import React from 'react';
import {Icon} from '../core/Icon.jsx';

/** Single-line field. Light on page surfaces, ink inside dark cards. */
export function Input({label,placeholder,value,onChange,type='text',iconName,tone='light',hint,style,...rest}){
  const dark=tone==='dark';
  const [focus,setFocus]=React.useState(false);
  return (
    <label style={{display:'block',...style}}>
      {label&&<span style={{display:'block',marginBottom:'8px',fontFamily:'var(--font-caps)',fontSize:'11.5px',letterSpacing:'var(--ls-caps-sm)',textTransform:'uppercase',color:dark?'var(--text-on-dark-muted)':'var(--text-muted)'}}>{label}</span>}
      <span style={{display:'flex',alignItems:'center',gap:'10px',background:dark?'var(--ink-900)':'var(--surface-card)',
        border:'1px solid '+(focus?'var(--accent)':(dark?'var(--border-hairline-dark)':'var(--border-hairline)')),
        borderRadius:'var(--r-sm)',padding:'12px 16px',transition:'border-color var(--dur-fast)',
        boxShadow:focus?'var(--sh-gold-ring)':'none'}}>
        {iconName&&<Icon name={iconName} size={17} style={{color:dark?'var(--text-on-dark-faint)':'var(--text-faint)'}}/>}
        <input type={type} placeholder={placeholder} value={value} onChange={onChange}
          onFocus={()=>setFocus(true)} onBlur={()=>setFocus(false)}
          style={{flex:1,background:'transparent',border:'none',outline:'none',fontFamily:'var(--font-sans)',fontSize:'var(--fs-body-sm)',color:dark?'var(--text-on-dark)':'var(--text-body)',minWidth:0}} {...rest}/>
      </span>
      {hint&&<span style={{display:'block',marginTop:'7px',fontFamily:'var(--font-sans)',fontSize:'var(--fs-micro)',color:dark?'var(--text-on-dark-faint)':'var(--text-faint)'}}>{hint}</span>}
    </label>
  );
}
