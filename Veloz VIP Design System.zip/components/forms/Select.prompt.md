Use for service type, vehicle category and passenger count.

```jsx
<Select label="Servicio" iconName="car-front" options={['Transfer aeropuerto','Por horas','Evento','Tour']} />
```
