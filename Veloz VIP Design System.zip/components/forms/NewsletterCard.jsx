import React from 'react';

/** Inline capture card used in the footer. */
export function NewsletterCard({title,description,placeholder='tu@correo.com',buttonLabel='Enviar',note,onSubmit,style,...rest}){
  const [value,setValue]=React.useState('');
  return (
    <div style={{background:'var(--surface-inverse-2)',border:'1px solid var(--border-hairline-dark)',borderRadius:'var(--r-xl)',padding:'28px',marginTop:'26px',...style}} {...rest}>
      <h4 style={{margin:'0 0 8px',fontFamily:'var(--font-display)',fontSize:'20px',fontWeight:'var(--fw-bold)',color:'var(--text-on-dark)'}}>{title}</h4>
      <p style={{margin:'0 0 20px',fontFamily:'var(--font-sans)',fontSize:'var(--fs-body-sm)',color:'var(--text-on-dark-muted)'}}>{description}</p>
      <div style={{display:'flex',gap:'10px',background:'var(--ink-900)',border:'1px solid rgba(255,255,255,.1)',borderRadius:'var(--r-sm)',padding:'6px 6px 6px 16px',marginBottom:'12px'}}>
        <input value={value} onChange={e=>setValue(e.target.value)} placeholder={placeholder}
          style={{flex:1,background:'transparent',border:'none',outline:'none',color:'var(--text-on-dark)',fontFamily:'var(--font-sans)',fontSize:'var(--fs-body-sm)',minWidth:0}}/>
        <button onClick={()=>onSubmit&&onSubmit(value)} style={{background:'var(--accent)',color:'var(--text-on-gold)',border:'none',borderRadius:'var(--r-xs)',padding:'11px 20px',fontFamily:'var(--font-sans)',fontWeight:'var(--fw-semibold)',fontSize:'var(--fs-body-sm)',cursor:'pointer',whiteSpace:'nowrap'}}>{buttonLabel}</button>
      </div>
      {note&&<div style={{fontFamily:'var(--font-sans)',fontSize:'var(--fs-micro)',color:'var(--text-on-dark-faint)'}}>{note}</div>}
    </div>
  );
}
