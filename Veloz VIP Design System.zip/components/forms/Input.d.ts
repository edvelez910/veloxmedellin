/** Labelled single-line field with an optional leading icon; gold focus ring. */
export interface InputProps {
  label?: React.ReactNode;
  placeholder?: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  type?: string;
  iconName?: string;
  tone?: 'light' | 'dark';
  hint?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Input(props: InputProps): JSX.Element;
