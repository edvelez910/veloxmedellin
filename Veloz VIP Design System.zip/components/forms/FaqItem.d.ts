/** Single FAQ accordion row; the +/− toggle turns gold when open. */
export interface FaqItemProps {
  question?: React.ReactNode;
  children?: React.ReactNode;
  /** Controlled open state; omit for self-managed. */
  open?: boolean;
  defaultOpen?: boolean;
  onToggle?: (next: boolean) => void;
  style?: React.CSSProperties;
}
export declare function FaqItem(props: FaqItemProps): JSX.Element;
