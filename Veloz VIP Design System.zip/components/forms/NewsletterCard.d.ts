/** Footer email-capture card on an ink surface with a gold submit button. */
export interface NewsletterCardProps {
  title?: React.ReactNode;
  description?: React.ReactNode;
  placeholder?: string;
  buttonLabel?: string;
  note?: React.ReactNode;
  onSubmit?: (value: string) => void;
  style?: React.CSSProperties;
}
export declare function NewsletterCard(props: NewsletterCardProps): JSX.Element;
