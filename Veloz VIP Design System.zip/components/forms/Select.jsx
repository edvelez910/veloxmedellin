import React from 'react';
import {Icon} from '../core/Icon.jsx';

/** Native select in the Input shell. */
export function Select({label,options=[],value,onChange,tone='light',iconName,style,...rest}){
  const dark=tone==='dark';
  return (
    <label style={{display:'block',...style}}>
      {label&&<span style={{display:'block',marginBottom:'8px',fontFamily:'var(--font-caps)',fontSize:'11.5px',letterSpacing:'var(--ls-caps-sm)',textTransform:'uppercase',color:dark?'var(--text-on-dark-muted)':'var(--text-muted)'}}>{label}</span>}
      <span style={{display:'flex',alignItems:'center',gap:'10px',background:dark?'var(--ink-900)':'var(--surface-card)',border:'1px solid '+(dark?'var(--border-hairline-dark)':'var(--border-hairline)'),borderRadius:'var(--r-sm)',padding:'12px 16px'}}>
        {iconName&&<Icon name={iconName} size={17} style={{color:dark?'var(--text-on-dark-faint)':'var(--text-faint)'}}/>}
        <select value={value} onChange={onChange} style={{flex:1,background:'transparent',border:'none',outline:'none',appearance:'none',fontFamily:'var(--font-sans)',fontSize:'var(--fs-body-sm)',color:dark?'var(--text-on-dark)':'var(--text-body)',minWidth:0}} {...rest}>
          {options.map(o=><option key={o.value||o} value={o.value||o} style={{color:'#16171a'}}>{o.label||o}</option>)}
        </select>
        <Icon name="chevron-down" size={17} style={{color:dark?'var(--text-on-dark-faint)':'var(--text-faint)'}}/>
      </span>
    </label>
  );
}
