Booking / contact fields. Labels are uppercase Inter, focus ring is gold.

```jsx
<Input label="Número de vuelo" placeholder="AV 8412" iconName="plane-landing" hint="Lo monitoreamos en tiempo real." />
```
