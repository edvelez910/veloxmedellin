Stack 4–6 with a 14px gap. Only one open at a time when controlled.

```jsx
<FaqItem question="¿Qué pasa si mi vuelo se retrasa?" defaultOpen>
  Monitoreamos tu vuelo en tiempo real y ajustamos la hora de recogida sin costo.
</FaqItem>
```
