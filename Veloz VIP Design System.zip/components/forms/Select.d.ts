/** Select field matching Input's shell. */
export interface SelectOption { value: string; label: string }
export interface SelectProps {
  label?: React.ReactNode;
  options?: (SelectOption | string)[];
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  tone?: 'light' | 'dark';
  iconName?: string;
  style?: React.CSSProperties;
}
export declare function Select(props: SelectProps): JSX.Element;
