Closes every page. The ghost wordmark is gold at 6% — never white.

```jsx
<Footer columns={[{title:'Servicios',links:[{label:'Transfers aeropuerto'}]}]}
  contact={{lines:['+57 300 000 0000','hola@veloxvip.co','Medellín, Colombia']}}
  socials={[{iconName:'instagram'},{iconName:'message-circle'}]}
  legal="© 2026 Velox VIP Services" assetBase="assets" />
```
