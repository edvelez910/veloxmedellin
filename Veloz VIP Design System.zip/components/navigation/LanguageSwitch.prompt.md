Language switcher for the nav bar. Spanish and English are the brand's predominant pair and always show as pills; Dutch, French, German, Portuguese and Italian sit behind the globe icon.

```jsx
<LanguageSwitch value={lang} onChange={setLang} languages={window.VELOX_LANGS} onDark />
```

Pair with a translations table keyed by the same codes (see `ui_kits/website/i18n.js` for the working example) — ES and EN carry full site copy; the other five fall back to English for data-driven content that hasn't been authored per-language.
