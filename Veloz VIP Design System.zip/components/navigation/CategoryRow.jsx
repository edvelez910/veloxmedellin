import React from 'react';

/** Oversized display row used for the service/category list on ink panels. */
export function CategoryRow({name,meta,onClick,first=false,style,...rest}){
  const [hover,setHover]=React.useState(false);
  return (
    <div onClick={onClick} onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)}
      style={{display:'flex',alignItems:'baseline',justifyContent:'space-between',gap:'16px',padding:'22px 0',
        borderTop:first?'1px solid var(--border-hairline-dark)':'none',borderBottom:'1px solid var(--border-hairline-dark)',
        cursor:'pointer',paddingLeft:hover?'14px':'0',transition:'padding-left var(--dur-base) var(--ease)',...style}} {...rest}>
      <span style={{fontFamily:'var(--font-display)',fontWeight:'var(--fw-bold)',fontSize:'clamp(32px,4.2vw,56px)',letterSpacing:'var(--ls-display)',lineHeight:1.05,
        color:hover?'var(--text-accent-on-dark)':'var(--text-on-dark)',transition:'color var(--dur-fast)'}}>{name}</span>
      <span style={{fontFamily:'var(--font-sans)',fontSize:'var(--fs-body)',color:'var(--text-on-dark-faint)',fontWeight:'var(--fw-medium)',whiteSpace:'nowrap'}}>{meta}</span>
    </div>
  );
}
