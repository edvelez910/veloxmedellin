import React from 'react';
import {BrandLockup} from '../core/BrandLockup.jsx';
import {Button} from '../core/Button.jsx';

/** Fixed transparent nav that condenses to a blurred ink bar once scrolled. */
export function NavBar({links=[],active,onNavigate,cta,scrolled=false,assetBase='../../assets',style,...rest}){
  return (
    <nav style={{position:'sticky',top:0,left:0,right:0,zIndex:100,display:'flex',alignItems:'center',justifyContent:'space-between',
      padding:scrolled?'14px 34px':'22px 34px',background:scrolled?'rgba(12,13,15,.72)':'transparent',
      backdropFilter:scrolled?'var(--blur-nav)':'none',boxShadow:scrolled?'var(--sh-nav)':'none',
      transition:'padding var(--dur-base) var(--ease),background var(--dur-base),box-shadow var(--dur-base)',...style}} {...rest}>
      <BrandLockup variant="onDark" size={30} assetBase={assetBase}/>
      <div style={{display:'flex',gap:'34px'}}>
        {links.map(l=>{
          const on=l.id===active;
          return <a key={l.id} href={l.href||'#'} onClick={e=>{if(onNavigate){e.preventDefault();onNavigate(l.id);}}}
            style={{fontFamily:'var(--font-sans)',fontSize:'var(--fs-body)',fontWeight:'var(--fw-medium)',textDecoration:'none',padding:'4px 0',position:'relative',
              color:on?'var(--text-on-dark)':'rgba(255,255,255,.82)',borderBottom:on?'2px solid var(--accent)':'2px solid transparent',transition:'color var(--dur-fast)'}}>{l.label}</a>;
        })}
      </div>
      {cta!==null&&(cta||<Button variant="ghost" size="sm" arrow>Reservar</Button>)}
    </nav>
  );
}
