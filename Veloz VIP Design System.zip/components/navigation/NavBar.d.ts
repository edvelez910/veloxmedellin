/** Site header. Transparent over the hero, blurred ink once scrolled. */
export interface NavLink { id: string; label: string; href?: string }
export interface NavBarProps {
  links?: NavLink[];
  /** id of the current link — gets a gold underline. */
  active?: string;
  onNavigate?: (id: string) => void;
  /** Custom right-hand action; pass null to remove it. */
  cta?: React.ReactNode | null;
  /** Condensed blurred state. */
  scrolled?: boolean;
  assetBase?: string;
  style?: React.CSSProperties;
}
export declare function NavBar(props: NavBarProps): JSX.Element;
