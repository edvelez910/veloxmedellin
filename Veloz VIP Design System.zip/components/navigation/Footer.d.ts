/** Site footer with link columns, contact block, socials and the oversized gold wordmark. */
export interface FooterColumn { title: string; links: { label: string; href?: string }[] }
export interface FooterProps {
  columns?: FooterColumn[];
  contact?: { title?: string; lines: React.ReactNode[] };
  /** Extra content under the brand — usually <NewsletterCard>. */
  children?: React.ReactNode;
  socials?: { iconName: string; href?: string }[];
  legal?: React.ReactNode;
  /** Ghost wordmark at the very bottom. */
  megaWord?: string;
  assetBase?: string;
  style?: React.CSSProperties;
}
export declare function Footer(props: FooterProps): JSX.Element;
