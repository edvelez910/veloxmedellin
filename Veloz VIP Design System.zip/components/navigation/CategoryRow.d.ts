/** Large display list row (services, categories) on an ink panel; indents 14px and turns gold on hover. */
export interface CategoryRowProps {
  name?: React.ReactNode;
  /** Right-hand metadata, e.g. "Desde COP 90.000". */
  meta?: React.ReactNode;
  /** Adds the top hairline — set on the first row only. */
  first?: boolean;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
export declare function CategoryRow(props: CategoryRowProps): JSX.Element;
