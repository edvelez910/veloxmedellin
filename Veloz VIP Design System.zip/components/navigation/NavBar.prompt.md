Header for every Velox page. Active link carries the gold underline (the template used white).

```jsx
<NavBar links={[{id:'home',label:'Inicio'},{id:'servicios',label:'Servicios'},{id:'flota',label:'Flota'}]}
  active="home" onNavigate={setView} assetBase="assets" />
```
