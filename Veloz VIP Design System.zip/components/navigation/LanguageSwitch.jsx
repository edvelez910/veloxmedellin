import React from 'react';
import {Icon} from '../core/Icon.jsx';

const PRIMARY=['es','en'];

/** Language switcher: ES/EN as direct pills, the rest tucked behind a globe dropdown. */
export function LanguageSwitch({value='es',onChange,languages=[],onDark=true,style,...rest}){
  const [open,setOpen]=React.useState(false);
  const primary=languages.filter(l=>PRIMARY.includes(l.code)).sort((a,b)=>PRIMARY.indexOf(a.code)-PRIMARY.indexOf(b.code));
  const secondary=languages.filter(l=>!PRIMARY.includes(l.code));
  const color=onDark?'var(--text-on-dark)':'var(--text-body)';
  const muted=onDark?'rgba(255,255,255,.62)':'var(--text-muted)';
  return (
    <div style={{position:'relative',display:'flex',alignItems:'center',gap:2,fontFamily:'var(--font-sans)',...style}} {...rest}>
      {primary.map(l=>(
        <button key={l.code} onClick={()=>onChange&&onChange(l.code)} style={{cursor:'pointer',background:'none',border:'none',padding:'6px 8px',fontSize:13,fontWeight:600,letterSpacing:'.02em',
          color:value===l.code?color:muted,borderBottom:value===l.code?'2px solid var(--accent)':'2px solid transparent',transition:'color var(--dur-fast)'}}>{l.code.toUpperCase()}</button>
      ))}
      <button onClick={()=>setOpen(o=>!o)} aria-label="Más idiomas" style={{cursor:'pointer',background:'none',border:'none',display:'flex',alignItems:'center',gap:4,padding:'6px',
        color:secondary.some(l=>l.code===value)?color:muted}}>
        <Icon name="globe" size={16}/>
        {secondary.some(l=>l.code===value)&&<span style={{fontSize:13,fontWeight:600}}>{value.toUpperCase()}</span>}
        <Icon name="chevron-down" size={13}/>
      </button>
      {open&&<div onMouseLeave={()=>setOpen(false)} style={{position:'absolute',top:'calc(100% + 10px)',right:0,minWidth:180,background:onDark?'var(--ink-850)':'var(--surface-card)',
        border:'1px solid '+(onDark?'var(--border-hairline-dark)':'var(--border-hairline)'),borderRadius:'var(--r-md)',boxShadow:'var(--sh-md)',padding:6,zIndex:50}}>
        {secondary.map(l=>(
          <button key={l.code} onClick={()=>{onChange&&onChange(l.code);setOpen(false);}} style={{display:'flex',width:'100%',alignItems:'center',justifyContent:'space-between',gap:10,cursor:'pointer',
            background:value===l.code?(onDark?'rgba(255,255,255,.08)':'var(--surface-sunken)'):'transparent',border:'none',borderRadius:'var(--r-xs)',padding:'9px 10px',
            color:onDark?'var(--text-on-dark)':'var(--text-body)',fontSize:13,textAlign:'left'}}>
            <span>{l.name}</span><span style={{color:muted,fontSize:11,fontWeight:600}}>{l.code.toUpperCase()}</span>
          </button>
        ))}
      </div>}
    </div>
  );
}
