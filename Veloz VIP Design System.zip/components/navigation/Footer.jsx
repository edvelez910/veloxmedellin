import React from 'react';
import {BrandLockup} from '../core/BrandLockup.jsx';
import {Icon} from '../core/Icon.jsx';

/** Ink footer: brand, contact card, link columns, socials and the oversized wordmark. */
export function Footer({columns=[],contact,children,socials=[],legal,megaWord='VELOX',assetBase='../../assets',style,...rest}){
  return (
    <footer style={{background:'var(--surface-inverse)',color:'var(--text-on-dark)',padding:'90px 0 0',overflow:'hidden',position:'relative',...style}} {...rest}>
      <div style={{maxWidth:'var(--maxw)',margin:'0 auto',padding:'0 var(--gutter)'}}>
        <div style={{display:'grid',gridTemplateColumns:'1.1fr .6fr .6fr .8fr',gap:'40px',paddingBottom:'70px'}}>
          <div>
            <BrandLockup variant="onDark" size={30} assetBase={assetBase}/>
            {children}
          </div>
          {columns.map((c,i)=>(
            <div key={i}>
              <h5 style={{margin:'0 0 22px',fontFamily:'var(--font-caps)',fontSize:'12.5px',letterSpacing:'var(--ls-caps)',textTransform:'uppercase',color:'var(--text-accent-on-dark)',fontWeight:'var(--fw-medium)'}}>{c.title}</h5>
              {c.links.map((l,j)=><a key={j} href={l.href||'#'} style={{display:'block',color:'var(--text-on-dark-muted)',fontFamily:'var(--font-sans)',fontSize:'var(--fs-body-sm)',marginBottom:'14px',textDecoration:'none'}}>{l.label}</a>)}
            </div>
          ))}
          {contact&&<div>
            <h5 style={{margin:'0 0 22px',fontFamily:'var(--font-caps)',fontSize:'12.5px',letterSpacing:'var(--ls-caps)',textTransform:'uppercase',color:'var(--text-accent-on-dark)',fontWeight:'var(--fw-medium)'}}>{contact.title||'Contacto'}</h5>
            {contact.lines.map((p,i)=><p key={i} style={{margin:'0 0 14px',color:'var(--text-on-dark-muted)',fontFamily:'var(--font-sans)',fontSize:'var(--fs-body-sm)',lineHeight:'var(--lh-body)'}}>{p}</p>)}
          </div>}
        </div>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'26px 0',borderTop:'1px solid var(--border-hairline-dark)',flexWrap:'wrap',gap:'16px'}}>
          <div style={{color:'var(--text-on-dark-faint)',fontFamily:'var(--font-sans)',fontSize:'var(--fs-caption)'}}>{legal}</div>
          <div style={{display:'flex',gap:'16px'}}>
            {socials.map((s,i)=><a key={i} href={s.href||'#'} aria-label={s.iconName} style={{color:'rgba(255,255,255,.45)',display:'grid',placeItems:'center'}}><Icon name={s.iconName} size={19}/></a>)}
          </div>
        </div>
      </div>
      <div aria-hidden="true" style={{fontFamily:'var(--font-display)',fontWeight:'var(--fw-black)',fontSize:'clamp(90px,20vw,300px)',letterSpacing:'var(--ls-mega)',lineHeight:.8,color:'rgba(201,169,107,.06)',textAlign:'center',marginTop:'-10px',userSelect:'none',whiteSpace:'nowrap'}}>{megaWord}</div>
    </footer>
  );
}
