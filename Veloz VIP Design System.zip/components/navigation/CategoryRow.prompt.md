Stacked in the split "servicios" panel next to a full-bleed photo.

```jsx
<CategoryRow first name="Transfers" meta="JMC · EOH" />
<CategoryRow name="City concierge" meta="Por horas o días" />
```
