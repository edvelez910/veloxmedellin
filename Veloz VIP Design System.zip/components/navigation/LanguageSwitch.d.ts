/**
 * Language switcher. Spanish and English render as direct pills (the brand's
 * predominant pair); the rest live behind a globe dropdown.
 * @startingPoint section="Navigation" subtitle="ES/EN pills plus a dropdown for 5 more languages" viewport="700x120"
 */
export interface LanguageOption { code: string; name: string }
export interface LanguageSwitchProps {
  /** Current language code, e.g. "es". */
  value?: string;
  onChange?: (code: string) => void;
  /** Full list, e.g. window.VELOX_LANGS — es and en are pulled out as the primary pair automatically. */
  languages?: LanguageOption[];
  onDark?: boolean;
  style?: React.CSSProperties;
}
export declare function LanguageSwitch(props: LanguageSwitchProps): JSX.Element;
