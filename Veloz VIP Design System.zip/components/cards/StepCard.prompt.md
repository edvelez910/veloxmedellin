Three across for the booking flow. Always ink cards on a light section — the contrast is the point.

```jsx
<StepCard number="01" iconName="message-circle" title="Escríbenos">Cuéntanos vuelo, fecha y número de pasajeros.</StepCard>
```
