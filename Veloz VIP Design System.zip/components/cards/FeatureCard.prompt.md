Bento tiles for service pillars — always over a real photograph, never a flat colour.

```jsx
<FeatureCard image="/img/conductor.jpg" iconName="user-check" title="Conductores de confianza">
  Personal verificado, presentación impecable y trato cálido paisa.
</FeatureCard>
```
