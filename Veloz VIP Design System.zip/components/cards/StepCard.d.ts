/** Numbered process step on an ink card with a gold ring icon. */
export interface StepCardProps {
  /** Zero-padded, e.g. "01". */
  number?: string;
  iconName?: string;
  title?: React.ReactNode;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function StepCard(props: StepCardProps): JSX.Element;
