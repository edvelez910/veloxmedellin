The fleet grid unit — two per row on desktop.

```jsx
<VehicleCard image="/img/suv.jpg" name="SUV & Camionetas" category="Grupos y corporativo"
  specs={[{iconName:'users',label:'6 pasajeros'},{iconName:'briefcase',label:'4 maletas'},{iconName:'snowflake',label:'A/C'}]}
  price="Desde COP 240.000" priceUnit="/ trayecto" />
```

Photo lifts 6px and zooms 1.06 on hover. Prices are always "Desde …" — Velox quotes per itinerary.
