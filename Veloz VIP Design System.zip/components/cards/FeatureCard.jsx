import React from 'react';
import {Icon} from '../core/Icon.jsx';

/** Photo-backed bento card: gradient scrim, icon badge, title and copy pinned to the bottom. */
export function FeatureCard({image,iconName,badge,title,children,minHeight=300,style,...rest}){
  return (
    <div style={{position:'relative',overflow:'hidden',borderRadius:'var(--r-2xl)',minHeight,display:'flex',flexDirection:'column',justifyContent:'flex-end',color:'var(--text-on-dark)',...style}} {...rest}>
      <div style={{position:'absolute',inset:0}}>
        {image&&<img src={image} alt="" style={{width:'100%',height:'100%',objectFit:'cover'}}/>}
        <div style={{position:'absolute',inset:0,background:'var(--overlay-card)'}}/>
      </div>
      {iconName&&<span style={{position:'absolute',top:22,left:22,width:44,height:44,borderRadius:'var(--r-sm)',background:'var(--surface-inverse)',border:'1px solid var(--border-gold)',display:'grid',placeItems:'center',zIndex:2,color:'var(--text-accent-on-dark)'}}>
        <Icon name={iconName} size={22}/>
      </span>}
      {badge&&<span style={{position:'absolute',top:20,left:'50%',transform:'translateX(-50%)',zIndex:2,background:'var(--glass-light)',border:'1px solid var(--border-glass)',backdropFilter:'var(--blur-glass)',borderRadius:'var(--r-pill)',padding:'8px 16px',fontFamily:'var(--font-sans)',fontWeight:'var(--fw-bold)',fontSize:'var(--fs-body)'}}>{badge}</span>}
      <div style={{position:'relative',zIndex:2,padding:'28px'}}>
        <h3 style={{margin:'0 0 10px',fontFamily:'var(--font-display)',fontSize:'22px',fontWeight:'var(--fw-bold)'}}>{title}</h3>
        <p style={{margin:0,fontFamily:'var(--font-sans)',fontSize:'var(--fs-body-sm)',color:'rgba(255,255,255,.78)',maxWidth:340,lineHeight:'var(--lh-body)'}}>{children}</p>
      </div>
    </div>
  );
}
