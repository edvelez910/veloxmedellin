Closing row of a bento grid or the end of a section.

```jsx
<CtaCard iconName="map-pin" title="Tu itinerario en Medellín, resuelto en una conversación."
  action={<Button variant="gold" arrow>Cotizar ahora</Button>} />
```
