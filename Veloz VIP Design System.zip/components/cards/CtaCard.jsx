import React from 'react';
import {Icon} from '../core/Icon.jsx';

/** Wide light card: ring icon, one headline, one button. */
export function CtaCard({iconName='star',title,action,tone='light',style,...rest}){
  const dark=tone==='dark';
  return (
    <div style={{background:dark?'var(--surface-inverse)':'var(--surface-card)',border:dark?'1px solid var(--border-hairline-dark)':'1px solid var(--border-hairline)',borderRadius:'var(--r-2xl)',padding:'34px 38px',display:'flex',alignItems:'center',justifyContent:'space-between',gap:'24px',flexWrap:'wrap',...style}} {...rest}>
      <div style={{display:'flex',alignItems:'center',gap:'20px'}}>
        <span style={{width:52,height:52,borderRadius:'var(--r-circle)',border:'1px solid var(--border-gold)',display:'grid',placeItems:'center',flex:'none',color:dark?'var(--text-accent-on-dark)':'var(--text-accent)'}}>
          <Icon name={iconName} size={24}/>
        </span>
        <h3 style={{margin:0,fontFamily:'var(--font-display)',fontSize:'22px',fontWeight:'var(--fw-bold)',maxWidth:440,lineHeight:1.28,color:dark?'var(--text-on-dark)':'var(--text-strong)'}}>{title}</h3>
      </div>
      {action}
    </div>
  );
}
