import React from 'react';
import {SpecChip} from '../core/SpecChip.jsx';

/** Fleet card: photo, category name, spec chips and a from-price. */
export function VehicleCard({image,name,category,specs=[],price,priceUnit='/ trayecto',footnote,onClick,style,...rest}){
  const [hover,setHover]=React.useState(false);
  return (
    <div onClick={onClick} onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)}
      style={{background:'var(--surface-card)',border:'1px solid var(--border-hairline)',borderRadius:'var(--r-3xl)',padding:'var(--pad-card)',cursor:onClick?'pointer':'default',
        transform:hover?'translateY(var(--lift-md))':'none',boxShadow:hover?'var(--sh-card-hover)':'none',
        transition:'transform var(--dur-slow) var(--ease),box-shadow var(--dur-slow) var(--ease)',...style}} {...rest}>
      <div style={{height:230,borderRadius:'var(--r-lg)',overflow:'hidden',background:'var(--surface-sunken)',marginBottom:'var(--sp-6)',position:'relative'}}>
        {image?<img src={image} alt={name} style={{width:'100%',height:'100%',objectFit:'cover',transform:hover?'scale(1.06)':'none',transition:'transform var(--dur-image) var(--ease)'}}/>:null}
        {category&&<span style={{position:'absolute',top:14,left:14,padding:'7px 14px',borderRadius:'var(--r-pill)',background:'var(--glass-dark)',border:'1px solid var(--border-glass)',backdropFilter:'var(--blur-glass)',color:'var(--text-on-dark)',fontFamily:'var(--font-caps)',fontSize:'11.5px',letterSpacing:'var(--ls-caps-sm)',textTransform:'uppercase'}}>{category}</span>}
      </div>
      <h3 style={{margin:'0 0 var(--sp-5)',paddingBottom:'var(--sp-5)',borderBottom:'1px solid var(--border-hairline)',fontFamily:'var(--font-display)',fontSize:'var(--fs-h3)',fontWeight:'var(--fw-bold)',letterSpacing:'var(--ls-tight)',color:'var(--text-strong)'}}>{name}</h3>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',gap:'14px',flexWrap:'wrap'}}>
        <div style={{display:'flex',gap:'8px',flexWrap:'wrap'}}>
          {specs.map((s,i)=><SpecChip key={i} iconName={s.iconName}>{s.label}</SpecChip>)}
        </div>
        {price&&<div style={{fontFamily:'var(--font-display)',fontWeight:'var(--fw-black)',fontSize:'26px',color:'var(--text-strong)',whiteSpace:'nowrap'}}>
          {price}<small style={{fontFamily:'var(--font-sans)',fontSize:'13px',color:'var(--text-muted)',fontWeight:'var(--fw-medium)',marginLeft:'4px'}}>{priceUnit}</small>
        </div>}
      </div>
      {footnote&&<p style={{margin:'var(--sp-4) 0 0',fontFamily:'var(--font-sans)',fontSize:'var(--fs-micro)',color:'var(--text-faint)'}}>{footnote}</p>}
    </div>
  );
}
