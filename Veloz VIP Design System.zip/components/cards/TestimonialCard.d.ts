/** Testimonial card: gold stars, quote, attribution, optional 120px portrait rail. */
export interface TestimonialCardProps {
  rating?: number;
  quote?: React.ReactNode;
  name?: string;
  role?: string;
  photo?: string;
  style?: React.CSSProperties;
}
export declare function TestimonialCard(props: TestimonialCardProps): JSX.Element;
