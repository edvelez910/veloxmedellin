/**
 * Fleet / vehicle-category card.
 */
export interface VehicleSpec { iconName?: string; label: string }
export interface VehicleCardProps {
  image?: string;
  name?: string;
  /** Glass capsule over the photo, e.g. "Sedán & Hatchback". */
  category?: string;
  /** Max 3 chips. */
  specs?: VehicleSpec[];
  /** Pre-formatted, e.g. "COP 180.000" or "Desde $45". */
  price?: string;
  /** Default "/ trayecto"; use "/ hora" or "/ día" for block hire. */
  priceUnit?: string;
  footnote?: string;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
export declare function VehicleCard(props: VehicleCardProps): JSX.Element;
