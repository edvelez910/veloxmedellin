import React from 'react';

/** Big display number over a hairline rule, with a caption. */
export function StatBlock({value,label,onDark=true,style,...rest}){
  return (
    <div style={{...style}} {...rest}>
      <div style={{fontFamily:'var(--font-display)',fontWeight:'var(--fw-black)',fontSize:'clamp(44px,5.4vw,74px)',letterSpacing:'var(--ls-mega)',lineHeight:1,marginBottom:'14px',paddingBottom:'20px',
        borderBottom:onDark?'1px solid var(--border-hairline-dark)':'1px solid var(--border-hairline)',
        color:onDark?'var(--text-on-dark)':'var(--text-strong)'}}>{value}</div>
      <p style={{margin:0,fontFamily:'var(--font-sans)',fontSize:'var(--fs-body)',color:onDark?'var(--text-on-dark-muted)':'var(--text-muted)'}}>{label}</p>
    </div>
  );
}
