import React from 'react';

/** Founder / promise quote in a light card — the brand's display voice. */
export function QuoteCard({children,author,role,avatar,style,...rest}){
  return (
    <div style={{maxWidth:640,margin:'0 auto',background:'var(--surface-card)',border:'1px solid var(--border-hairline)',borderRadius:'var(--r-3xl)',padding:'44px 40px',boxShadow:'var(--sh-card)',textAlign:'center',...style}} {...rest}>
      <p style={{margin:'0 0 26px',fontFamily:'var(--font-display)',fontSize:'22px',fontStyle:'italic',fontWeight:'var(--fw-medium)',color:'var(--text-strong)',lineHeight:1.4}}>{children}</p>
      <div style={{display:'flex',alignItems:'center',justifyContent:'center',gap:'12px'}}>
        {avatar&&<img src={avatar} alt={author} style={{width:38,height:38,borderRadius:'var(--r-circle)',objectFit:'cover'}}/>}
        <span style={{fontFamily:'var(--font-sans)',fontSize:'var(--fs-body-sm)',color:'var(--text-muted)',fontWeight:'var(--fw-medium)'}}>{author}{role?', '+role:''}</span>
      </div>
    </div>
  );
}
