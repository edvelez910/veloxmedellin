/**
 * Photo bento card with a bottom-anchored caption.
 */
export interface FeatureCardProps {
  image?: string;
  /** Lucide glyph in the top-left square badge. */
  iconName?: string;
  /** Centred glass capsule at the top, e.g. "24/7". */
  badge?: React.ReactNode;
  title?: React.ReactNode;
  children?: React.ReactNode;
  minHeight?: number;
  style?: React.CSSProperties;
}
export declare function FeatureCard(props: FeatureCardProps): JSX.Element;
