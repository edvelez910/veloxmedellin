/** Centred display quote card with attribution. */
export interface QuoteCardProps {
  children?: React.ReactNode;
  author?: string;
  role?: string;
  avatar?: string;
  style?: React.CSSProperties;
}
export declare function QuoteCard(props: QuoteCardProps): JSX.Element;
