/** Wide banner card pairing one line of copy with one button. */
export interface CtaCardProps {
  iconName?: string;
  title?: React.ReactNode;
  /** A <Button>. */
  action?: React.ReactNode;
  tone?: 'light' | 'dark';
  style?: React.CSSProperties;
}
export declare function CtaCard(props: CtaCardProps): JSX.Element;
