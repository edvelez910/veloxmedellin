Three across inside a dark testimonials section.

```jsx
<TestimonialCard rating={5} quote="Nos esperaron con el marcador aunque el vuelo llegó dos horas tarde." name="Laura Restrepo" role="Viaje corporativo" photo="/img/laura.jpg" />
```
