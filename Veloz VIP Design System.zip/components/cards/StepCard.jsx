import React from 'react';
import {Icon} from '../core/Icon.jsx';

/** Numbered dark step card — "cómo funciona". */
export function StepCard({number,iconName,title,children,style,...rest}){
  const [hover,setHover]=React.useState(false);
  return (
    <div onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)}
      style={{background:'var(--surface-inverse)',color:'var(--text-on-dark)',borderRadius:'var(--r-2xl)',padding:'34px 30px 40px',textAlign:'center',minHeight:360,display:'flex',flexDirection:'column',alignItems:'center',
        transform:hover?'translateY(var(--lift-lg))':'none',transition:'transform var(--dur-slow) var(--ease)',...style}} {...rest}>
      <span style={{fontFamily:'var(--font-caps)',fontSize:'13px',letterSpacing:'var(--ls-caps-sm)',color:'var(--text-accent-on-dark)',fontWeight:'var(--fw-medium)',marginBottom:'auto'}}>{number}</span>
      <span style={{width:74,height:74,borderRadius:'var(--r-circle)',border:'1px solid var(--border-gold)',display:'grid',placeItems:'center',margin:'28px 0',color:'var(--text-accent-on-dark)'}}>
        <Icon name={iconName} size={32}/>
      </span>
      <h3 style={{margin:'16px 0 12px',fontFamily:'var(--font-display)',fontSize:'21px',fontWeight:'var(--fw-bold)'}}>{title}</h3>
      <p style={{margin:0,fontFamily:'var(--font-sans)',fontSize:'var(--fs-body-sm)',color:'var(--text-on-dark-muted)',maxWidth:250,lineHeight:'var(--lh-body)'}}>{children}</p>
    </div>
  );
}
