import React from 'react';
import {StarRating} from '../core/StarRating.jsx';

/** Client testimonial on an ink card, with optional portrait rail. */
export function TestimonialCard({rating=5,quote,name,role,photo,style,...rest}){
  return (
    <div style={{background:'var(--surface-inverse-card)',border:'1px solid rgba(255,255,255,.07)',borderRadius:'var(--r-3xl)',padding:'26px',display:'flex',gap:'22px',color:'var(--text-on-dark)',...style}} {...rest}>
      <div style={{flex:1,display:'flex',flexDirection:'column'}}>
        <div style={{marginBottom:'16px'}}><StarRating value={rating}/></div>
        <p style={{margin:'0 0 auto',fontFamily:'var(--font-sans)',fontSize:'var(--fs-body)',lineHeight:'var(--lh-body)',color:'rgba(255,255,255,.82)'}}>{quote}</p>
        <div style={{marginTop:'24px'}}>
          <b style={{display:'block',fontFamily:'var(--font-display)',fontSize:'18px',fontWeight:'var(--fw-bold)'}}>{name}</b>
          <span style={{fontFamily:'var(--font-sans)',fontSize:'13px',color:'var(--text-on-dark-faint)'}}>{role}</span>
        </div>
      </div>
      {photo&&<div style={{width:120,flex:'none',borderRadius:'var(--r-md)',overflow:'hidden'}}>
        <img src={photo} alt={name} style={{width:'100%',height:'100%',objectFit:'cover'}}/>
      </div>}
    </div>
  );
}
