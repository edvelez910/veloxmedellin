Four across on the dark stats band.

```jsx
<StatBlock value="24/7" label="Coordinación y seguimiento de vuelos" />
```

Only claim numbers Velox can back up.
