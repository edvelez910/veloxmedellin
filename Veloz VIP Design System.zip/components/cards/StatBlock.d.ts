/** Display-number statistic with a hairline rule and caption. */
export interface StatBlockProps {
  /** Pre-formatted, e.g. "24/7", "+1.200", "98%". */
  value?: React.ReactNode;
  label?: React.ReactNode;
  onDark?: boolean;
  style?: React.CSSProperties;
}
export declare function StatBlock(props: StatBlockProps): JSX.Element;
