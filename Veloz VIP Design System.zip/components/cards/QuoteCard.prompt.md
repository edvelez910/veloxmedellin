Reserved for the brand promise and founder lines — italic Inter Tight, centred.

```jsx
<QuoteCard author="Velox VIP Services">"Tu tranquilidad, nuestra ruta."</QuoteCard>
```
