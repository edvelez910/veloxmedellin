# Velox VIP Services — Design System

Movilidad privada y **concierge de experiencias** en Medellín y sus alrededores. Velox no es una
app de transporte rápido ni una rentadora de vehículos: es el aliado logístico de confianza de sus
clientes en la ciudad. La marca vive en tres colores — **oro champán, negro mate y blanco** — y en una
promesa: *«Tu tranquilidad, nuestra ruta.»*

---

## 1. Fuentes que se usaron para construir este sistema

| Fuente | Qué aportó | Ruta / enlace |
|---|---|---|
| Logo oficial, placa clara (v2) | Color oro exacto (#c9a96b), wordmark "Velox" en minúscula inicial, lockup | `uploads/1-3e738b6a.png` → `assets/logo-velox-onlight.png` |
| Logo oficial, placa oscura (v2) | Negro mate #242424, versión sobre oscuro | `uploads/2-ac7b66aa.png` → `assets/logo-velox-ondark.png` |
| Fuente de marca — Higuen | Serif del wordmark, ahora real (no sustituida) | `uploads/higuen-regular_freefontdownload_org/` → `assets/fonts/higuen-regular.otf` |
| Fuente de marca — Glacial Indifference | Geométrica de "VIP SERVICES", ahora real | `uploads/glacial-indifference-regular_freefontdownload_org/` → `assets/fonts/glacial-indifference-regular.otf` |
| Plantilla del sitio web | **Toda la estructura, radios, sombras, ritmo vertical, curva de easing y patrones de sección** | `uploads/plantilla pagina web.html` |
| Carpeta local adjunta | Contenía los mismos tres archivos | `Velox Medellin/` (montada en modo lectura) |
| Brief de marca (chat) | Portafolio de servicios, flota, pilares, tono de voz | mensaje del cliente |

> ⚠️ **Sobre la plantilla.** El archivo entregado es el tema comercial **"Carent — Drive Luxury"**
> (Webestica / Framer): una plantilla genérica de renta de autos, en inglés, con la marca "Carent",
> logotipos de fabricantes y sedes en Estados Unidos. **No es la web de Velox.** Se tomó como
> referencia *estructural* (tokens de layout, anatomía de tarjetas, secciones, animaciones) y se
> re-vistió con la identidad Velox. Nada de su copy, marca o contenido se conservó.

**Sin repositorio de código, sin Figma y sin fuentes tipográficas** entre los materiales entregados.

---

## 2. Índice de archivos

| Ruta | Contenido |
|---|---|
| `styles.css` | Único punto de entrada CSS: sólo `@import` |
| `tokens/colors.css` | Rampas oro / negro / neutros + alias semánticos + overlays |
| `tokens/typography.css` | Familias, escala, pesos, tracking |
| `tokens/fonts.css` | `@import` de Google Fonts (Inter, Inter Tight) |
| `tokens/spacing.css` `radius.css` `elevation.css` `motion.css` `layout.css` | Espaciado, radios, sombras, movimiento, anchos |
| `assets/` | Logos (placa clara / oscura / transparentes) y estrella suelta |
| `components/core/` | `Icon` `Button` `Pill` `Eyebrow` `SectionHeading` `StarRating` `SpecChip` `ArrowButton` `BrandLockup` |
| `components/cards/` | `VehicleCard` `StepCard` `TestimonialCard` `QuoteCard` `FeatureCard` `CtaCard` `StatBlock` |
| `components/navigation/` | `NavBar` `Footer` `CategoryRow` |
| `components/forms/` | `Input` `Select` `NewsletterCard` `FaqItem` |
| `components/marketing/` | `Hero` `Marquee` `LocationPill` `FeatureRow` |
| `ui_kits/website/` | Sitio Velox completo, click-through (4 pantallas) — ver su `README.md` |
| `templates/landing/` | Plantilla reutilizable «Landing Velox VIP» (hero, pilares, servicios, flota, cierre) |
| `guidelines/*.html` | 23 fichas de fundamentos (marca, color, tipografía, espaciado, sistemas) |
| `thumbnail.html` | Tile del sistema |
| `SKILL.md` | Envoltura para usar este sistema como Agent Skill |

Cada componente trae `<Name>.d.ts` (contrato de props) y `<Name>.prompt.md` (cuándo y cómo usarlo).

### Adiciones intencionales
La plantilla no define una librería de componentes con nombres; el inventario se derivó de sus
patrones de sección. Dos piezas se añadieron por necesidad práctica:
- **`Icon`** — envoltorio de glifos Lucide, para no dibujar SVG a mano (ver §6).
- **`BrandLockup`** — envoltorio del logo suministrado, para que nunca se redibuje la marca.

---

## 3. Fundamentos de contenido (CONTENT FUNDAMENTALS)

**Idioma:** español de Colombia. Registro paisa profesional, sin modismos cerrados.
**Persona:** **tú**, nunca *usted* ni *ustedes*. La marca habla en **nosotros**
(«monitoreamos», «te esperamos», «nos encargamos»). Nunca en tercera persona ni en pasiva.

**Casing:** oraciones normales, con mayúscula sólo al inicio. Los títulos NO van en Title Case.
Los *eyebrows* y las etiquetas de campo sí van en MAYÚSCULAS con tracking ancho.

**Tono:** *sofisticado pero cercano*. Elegante en la presentación, cálido en el trato. Se promete
lo que se puede cumplir; nada de superlativos vacíos («el mejor», «lujo inigualable», «exclusivo»).
La tranquilidad se demuestra con hechos concretos, no con adjetivos.

**Sí:**
- «Tu tranquilidad, nuestra ruta.»
- «Monitoreamos la llegada de tu vuelo para estar en la puerta en el momento exacto.»
- «El estándar VIP no depende del carro, sino del trato y la logística.»
- «Cómodo, ágil y de alta calidad a un precio muy accesible.»
- «Te escribimos por WhatsApp en menos de 30 minutos.»

**No:**
- «La experiencia de lujo definitiva en Medellín» (vacío)
- «Reserve su vehículo ahora» (usted + verbo de rentadora)
- «Servicio Premium Exclusivo VIP» (Title Case + apilado de adjetivos)
- «Precios desde $10 USD» (Velox cotiza en COP y por itinerario)

**Longitudes.** Titular: 3–8 palabras. Bajada/lead: 1–2 frases, máx. 240 caracteres. Copy de
tarjeta: 1 frase. Etiqueta de botón: 2–4 palabras, siempre en imperativo de acción
(«Reservar», «Cotizar ahora», «Ver la flota», «Hablar con Velox»).

**Precios.** Siempre «Desde COP …» + unidad («/ trayecto», «/ hora»). Nunca un precio cerrado sin
«desde»: la tarifa final depende del itinerario. Nunca cobro en línea; el cierre es por WhatsApp.

**Emoji:** **no se usan**, en ningún caso. Ni en web, ni en slides, ni en botones. El acento
decorativo de la marca es el oro y la estrella, no un emoji.

**Números y unidades.** Miles con punto (COP 150.000). Horas en 24 h («14:30»). Aeropuertos por
sigla: **JMC** (Rionegro) y **EOH** (Olaya Herrera). Ciudad: Medellín; región: Oriente antioqueño.

---

## 4. Fundamentos visuales (VISUAL FOUNDATIONS)

### Color
Oro champán **#c9a96b** (`--gold-500`) es el único color de marca; todo lo demás es negro mate,
blanco y grises. El oro se usa **con moderación**: un CTA por vista, anillos de icono, filetes,
subrayado del nav activo, estrellas de rating, palabra fantasma. Nunca como fondo de una sección
completa ni como gradiente de marca. Máximo dos fondos por página: `--surface-page` (#f4f4f5) y
`--surface-inverse` (#0c0d0f). El oro sobre blanco sólo en texto ≥24 px.

### Tipografía
El sitio usa las dos familias de la plantilla del cliente — **decisión suya: la interfaz no usa
el serif del logo**, sólo el logotipo lo lleva.
- **Inter Tight** (`--font-display`) — titulares, nombres de vehículo, cifras grandes y citas.
- **Inter** (`--font-sans` y `--font-caps`) — párrafos, botones, chips, formularios, eyebrows.
- **Higuen** y **Glacial Indifference** (`assets/fonts/`) son las fuentes reales del logotipo
  — declaradas en `tokens/fonts.css` para uso de marca/impresión, pero **no** se usan en la
  interfaz del sitio por pedido explícito del cliente.

Tracking negativo en display (−.02em); ninguno en texto corrido. Interlineado 1.04–1.12 en
titulares, 1.55–1.6 en párrafos.

### Fondos e imágenes
Fotografía **cálida y oscura**: noches, luz de tarde, interiores de vehículo, Medellín y Guatapé.
Nada de blanco y negro, nada de grano, nada de filtros fríos ni azulados. Los héroes son
**full-bleed** con degradado de protección (`--overlay-hero`); las tarjetas de foto llevan
`--overlay-card` antes de recibir texto. **No hay ilustración, ni patrones, ni texturas, ni
gradientes de color como fondo** — sólo foto, negro mate o blanco. El único "gradiente" permitido
es el scrim negro y el filete `--gold-rule`.

### Tarjetas
Blancas, radio 30 px (`--r-3xl`), borde hairline de 1 px, **sin sombra en reposo**. Foto interior
con radio 18 px y altura fija. Título display con filete inferior a 18 px. Las tarjetas oscuras
(pasos, testimonios) usan `--ink-750` con borde blanco al 7 % y radio 26 px. Las bento con foto no
tienen borde: el scrim hace el trabajo.

### Radios
9 · 12 · 16 · 18 · 22 · 26 · 30 px y la píldora (`999px`). **Ningún elemento con esquina viva**,
salvo la insignia cuadrada de icono (radio 12 px) sobre las bento.

### Sombras
Muy difusas y muy suaves: `0 4px 14px rgba(0,0,0,.04)` hasta `0 30px 60px rgba(0,0,0,.06)`. No hay
sombras duras ni sombras internas (inset) en ninguna parte. El botón oro tiene su propia sombra
teñida (`--sh-gold`). El nav pegado usa `--sh-nav` (25 % de negro).

### Transparencia y blur
Sólo en tres lugares: el nav al hacer scroll (`rgba(12,13,15,.72)` + blur 16), las píldoras
*glass* sobre fotografía (`rgba(18,18,20,.55)` + blur 12) y las insignias flotantes sobre imagen.
Nunca "glassmorphism" sobre fondos planos.

### Movimiento
Una sola curva: **`cubic-bezier(.22,1,.36,1)`** (`--ease`). Duraciones 0.3 / 0.4 / 0.5 / 0.7 s.
- **Hover:** botones suben 3 px; tarjetas claras 6 px; tarjetas oscuras 8 px; la foto interior
  escala a 1.06 en 0.7 s; la flecha → se desplaza 5 px.
- **Press:** `scale(.94)` en botones circulares; los pill sólo oscurecen.
- **Reveal al scroll:** `opacity 0→1` + `translateY(38px→0)` en 0.9 s, con retardos de 80 ms.
- **Ambiente:** marquees lineales infinitos (18 / 32 / 40 s) con máscara de bordes.
- **Prohibido:** bounce, rebote, rotaciones, parpadeos, entradas por escala.

### Estados
Hover en enlaces = aclarar a blanco (sobre oscuro) o al oro (sobre claro), nunca subrayado nuevo.
Nav activo = subrayado oro de 2 px. Foco = borde oro + anillo `--sh-gold-ring`. Deshabilitado =
opacidad .42 sin sombra. FAQ abierto = borde oro + toggle relleno de oro.

### Layout
Ancho máximo 1240 px, gutter 28 px (20 px en móvil). Ritmo vertical de 110 px por sección
(74 px bajo 600 px). Grid de tarjetas: 2 columnas para flota, 3 para pasos y testimonios, bento de
`1.15fr 1fr 1fr`. El nav es **fijo**; nada más se fija ni se pega. Los paneles partidos
(foto | panel oscuro) van a sangre completa, sin gutter.

### Iconografía → §6

---

## 5. Sustituciones que necesitan tu confirmación (historial)

1. **Tipografía de la interfaz.** El cliente probó Higuen (serif del logo) como fuente del sitio y
   no le gustó; la interfaz vuelve a Inter + Inter Tight, las de su plantilla original. Higuen y
   Glacial Indifference quedan declaradas en `tokens/fonts.css` para uso de marca/impresión, no
   para pantalla.
1. **Iconos.** La plantilla usaba SVG dibujados a mano, sin librería. Se adoptó **Lucide** (24 px,
   trazo 1.5–2, esquinas redondeadas), que es la coincidencia más cercana, cargado por CDN.
3. **Fotografía.** Todo es placeholder de Unsplash. Hace falta material real: flota, conductores,
   recepción en el aeropuerto, Medellín de noche, Guatapé.

---

## 6. Iconografía (ICONOGRAPHY)

- **Sistema:** [Lucide](https://lucide.dev) — 24 px, trazo 1.5–2 px, terminaciones redondeadas,
  estilo lineal (nunca relleno). Se consume vía el componente `Icon`, que enmascara el SVG con
  `currentColor` para que herede el color del contenedor. **Sustitución declarada:** la plantilla
  original dibujaba cada icono a mano; Lucide es el equivalente más cercano en peso y estilo.
- **No hay** fuente de iconos propia, ni sprite, ni PNG de iconos en los materiales entregados.
  Por eso Lucide se carga desde CDN (`unpkg.com/lucide-static@0.436.0`) en vez de copiarse al
  proyecto. Si se necesita offline, hay que descargar el paquete a `assets/icons/`.
- **Tamaños:** 15 px en chips de especificación · 17 px en píldoras y campos · 20 px inline ·
  22 px en insignias cuadradas · 24 px en anillos de 52 px · 32 px en anillos de 74 px ·
  38 px en los pilares.
- **Color:** heredado. Sobre claro, `--text-accent`; sobre oscuro, `--text-accent-on-dark`; en
  texto corrido, el color del texto. Nunca dos colores en un mismo icono.
- **Glifos canónicos:** `plane-landing` (transfers) · `clock` (24/7, bloques por horas) ·
  `shield-check` (seguridad) · `radar` (seguimiento en vivo) · `route` (itinerarios) ·
  `car-front` / `bus` (flota) · `users` (pasajeros) · `briefcase` (maletas) · `map-pin`
  (destinos) · `utensils` (reservas) · `party-popper` (eventos) · `user-check` (conductores) ·
  `message-circle` (WhatsApp) · `calendar` · `receipt` (tarifa cerrada) · `headset` (soporte).
- **Unicode:** se usa **★ (U+2605)** para las estrellas de rating, en oro, porque la marca es una
  estrella y el glifo relleno es más fiel que un contorno. Y la flecha **→** dentro de los botones.
  Ningún otro carácter hace de icono.
- **Emoji:** nunca, en ningún soporte.
- **Logo ≠ icono.** La estrella Velox (`assets/mark-velox-star.png`) es marca, no icono: no se usa
  como viñeta ni dentro de botones. Mínimo 20 px de altura.

---

## 7. Cómo consumir este sistema

```html
<link rel="stylesheet" href="styles.css">
<script src="_ds_bundle.js"></script>
<script type="text/babel">
  const {Button,Pill,VehicleCard} = window.VelozVIPDesignSystem_b0ea98;
</script>
```

Copia `assets/` junto al HTML y apunta `assetBase` de `BrandLockup` / `NavBar` / `Footer` a esa
carpeta. Usa siempre los alias semánticos (`--surface-card`, `--text-muted`) antes que los valores
crudos de la rampa.
